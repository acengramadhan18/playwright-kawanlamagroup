var browserWorkerPolyFill = function(e){e.on=e.addEventListener
e.off=e.removeEventListener
return e};
browserWorkerPolyFill(self);
var e=function(){this.init=function(){var e={}
this.on=function(t,i){e[t]||(e[t]=[])
e[t]=e[t].concat(i)}
this.off=function(t,i){var n
if(!e[t])return!1
n=e[t].indexOf(i)
e[t]=e[t].slice()
e[t].splice(n,1)
return n>-1}
this.trigger=function(t){var i,n,r,a
if(i=e[t])if(2===arguments.length){r=i.length
for(n=0;n<r;++n)i[n].call(this,arguments[1])}else{a=[]
n=arguments.length
for(n=1;n<arguments.length;++n)a.push(arguments[n])
r=i.length
for(n=0;n<r;++n)i[n].apply(this,a)}}
this.dispose=function(){e={}}}}
e.prototype.pipe=function(e){this.on("data",(function(t){e.push(t)}))
this.on("done",(function(t){e.flush(t)}))
this.on("partialdone",(function(t){e.partialFlush(t)}))
this.on("endedtimeline",(function(t){e.endTimeline(t)}))
this.on("reset",(function(t){e.reset(t)}))
return e}
e.prototype.push=function(e){this.trigger("data",e)}
e.prototype.flush=function(e){this.trigger("done",e)}
e.prototype.partialFlush=function(e){this.trigger("partialdone",e)}
e.prototype.endTimeline=function(e){this.trigger("endedtimeline",e)}
e.prototype.reset=function(e){this.trigger("reset",e)}
var t,i,n,r,a,s,o,u,l,c,d,h,p,f,m,g,v,y,_,b,T,k,S,E,C,w,I,P,x,A,O,L,D,R,M,N,U=e,B=Math.pow(2,32),F={getUint64:function(e){var t,i=new DataView(e.buffer,e.byteOffset,e.byteLength)
return i.getBigUint64?(t=i.getBigUint64(0))<Number.MAX_SAFE_INTEGER?Number(t):t:i.getUint32(0)*B+i.getUint32(4)},MAX_UINT32:B},j=F.MAX_UINT32
!function(){var e
S={avc1:[],avcC:[],btrt:[],dinf:[],dref:[],esds:[],ftyp:[],hdlr:[],mdat:[],mdhd:[],mdia:[],mfhd:[],minf:[],moof:[],moov:[],mp4a:[],mvex:[],mvhd:[],pasp:[],sdtp:[],smhd:[],stbl:[],stco:[],stsc:[],stsd:[],stsz:[],stts:[],styp:[],tfdt:[],tfhd:[],traf:[],trak:[],trun:[],trex:[],tkhd:[],vmhd:[]}
if("undefined"!=typeof Uint8Array){for(e in S)S.hasOwnProperty(e)&&(S[e]=[e.charCodeAt(0),e.charCodeAt(1),e.charCodeAt(2),e.charCodeAt(3)])
E=new Uint8Array(["i".charCodeAt(0),"s".charCodeAt(0),"o".charCodeAt(0),"m".charCodeAt(0)])
w=new Uint8Array(["a".charCodeAt(0),"v".charCodeAt(0),"c".charCodeAt(0),"1".charCodeAt(0)])
C=new Uint8Array([0,0,0,1])
I=new Uint8Array([0,0,0,0,0,0,0,0,118,105,100,101,0,0,0,0,0,0,0,0,0,0,0,0,86,105,100,101,111,72,97,110,100,108,101,114,0])
P=new Uint8Array([0,0,0,0,0,0,0,0,115,111,117,110,0,0,0,0,0,0,0,0,0,0,0,0,83,111,117,110,100,72,97,110,100,108,101,114,0])
x={video:I,audio:P}
L=new Uint8Array([0,0,0,0,0,0,0,1,0,0,0,12,117,114,108,32,0,0,0,1])
O=new Uint8Array([0,0,0,0,0,0,0,0])
D=new Uint8Array([0,0,0,0,0,0,0,0])
R=D
M=new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0])
N=D
A=new Uint8Array([0,0,0,1,0,0,0,0,0,0,0,0])}}()
t=function(e){var t,i,n=[],r=0
for(t=1;t<arguments.length;t++)n.push(arguments[t])
t=n.length
for(;t--;)r+=n[t].byteLength
i=new Uint8Array(r+8)
new DataView(i.buffer,i.byteOffset,i.byteLength).setUint32(0,i.byteLength)
i.set(e,4)
for(t=0,r=8;t<n.length;t++){i.set(n[t],r)
r+=n[t].byteLength}return i}
i=function(){return t(S.dinf,t(S.dref,L))}
n=function(e){return t(S.esds,new Uint8Array([0,0,0,0,3,25,0,0,0,4,17,64,21,0,6,0,0,0,218,192,0,0,218,192,5,2,e.audioobjecttype<<3|e.samplingfrequencyindex>>>1,e.samplingfrequencyindex<<7|e.channelcount<<3,6,1,2]))}
r=function(){return t(S.ftyp,E,C,E,w)}
g=function(e){return t(S.hdlr,x[e])}
a=function(e){return t(S.mdat,e)}
m=function(e){var i=new Uint8Array([0,0,0,0,0,0,0,2,0,0,0,3,0,1,95,144,e.duration>>>24&255,e.duration>>>16&255,e.duration>>>8&255,255&e.duration,85,196,0,0])
if(e.samplerate){i[12]=e.samplerate>>>24&255
i[13]=e.samplerate>>>16&255
i[14]=e.samplerate>>>8&255
i[15]=255&e.samplerate}return t(S.mdhd,i)}
f=function(e){return t(S.mdia,m(e),g(e.type),o(e))}
s=function(e){return t(S.mfhd,new Uint8Array([0,0,0,0,(4278190080&e)>>24,(16711680&e)>>16,(65280&e)>>8,255&e]))}
o=function(e){return t(S.minf,"video"===e.type?t(S.vmhd,A):t(S.smhd,O),i(),y(e))}
u=function(e,i){for(var n=[],r=i.length;r--;)n[r]=b(i[r])
return t.apply(null,[S.moof,s(e)].concat(n))}
l=function(e){for(var i=e.length,n=[];i--;)n[i]=h(e[i])
return t.apply(null,[S.moov,d(4294967295)].concat(n).concat(c(e)))}
c=function(e){for(var i=e.length,n=[];i--;)n[i]=T(e[i])
return t.apply(null,[S.mvex].concat(n))}
d=function(e){var i=new Uint8Array([0,0,0,0,0,0,0,1,0,0,0,2,0,1,95,144,(4278190080&e)>>24,(16711680&e)>>16,(65280&e)>>8,255&e,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255])
return t(S.mvhd,i)}
v=function(e){var i,n,r=e.samples||[],a=new Uint8Array(4+r.length)
for(n=0;n<r.length;n++){i=r[n].flags
a[n+4]=i.dependsOn<<4|i.isDependedOn<<2|i.hasRedundancy}return t(S.sdtp,a)}
y=function(e){return t(S.stbl,_(e),t(S.stts,N),t(S.stsc,R),t(S.stsz,M),t(S.stco,D))}
!function(){var e,i
_=function(n){return t(S.stsd,new Uint8Array([0,0,0,0,0,0,0,1]),"video"===n.type?e(n):i(n))}
e=function(e){var i,n,r=e.sps||[],a=e.pps||[],s=[],o=[]
for(i=0;i<r.length;i++){s.push((65280&r[i].byteLength)>>>8)
s.push(255&r[i].byteLength)
s=s.concat(Array.prototype.slice.call(r[i]))}for(i=0;i<a.length;i++){o.push((65280&a[i].byteLength)>>>8)
o.push(255&a[i].byteLength)
o=o.concat(Array.prototype.slice.call(a[i]))}n=[S.avc1,new Uint8Array([0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,(65280&e.width)>>8,255&e.width,(65280&e.height)>>8,255&e.height,0,72,0,0,0,72,0,0,0,0,0,0,0,1,19,118,105,100,101,111,106,115,45,99,111,110,116,114,105,98,45,104,108,115,0,0,0,0,0,0,0,0,0,0,0,0,0,24,17,17]),t(S.avcC,new Uint8Array([1,e.profileIdc,e.profileCompatibility,e.levelIdc,255].concat([r.length],s,[a.length],o))),t(S.btrt,new Uint8Array([0,28,156,128,0,45,198,192,0,45,198,192]))]
if(e.sarRatio){var u=e.sarRatio[0],l=e.sarRatio[1]
n.push(t(S.pasp,new Uint8Array([(4278190080&u)>>24,(16711680&u)>>16,(65280&u)>>8,255&u,(4278190080&l)>>24,(16711680&l)>>16,(65280&l)>>8,255&l])))}return t.apply(null,n)}
i=function(e){return t(S.mp4a,new Uint8Array([0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,(65280&e.channelcount)>>8,255&e.channelcount,(65280&e.samplesize)>>8,255&e.samplesize,0,0,0,0,(65280&e.samplerate)>>8,255&e.samplerate,0,0]),n(e))}}()
p=function(e){var i=new Uint8Array([0,0,0,7,0,0,0,0,0,0,0,0,(4278190080&e.id)>>24,(16711680&e.id)>>16,(65280&e.id)>>8,255&e.id,0,0,0,0,(4278190080&e.duration)>>24,(16711680&e.duration)>>16,(65280&e.duration)>>8,255&e.duration,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,64,0,0,0,(65280&e.width)>>8,255&e.width,0,0,(65280&e.height)>>8,255&e.height,0,0])
return t(S.tkhd,i)}
b=function(e){var i,n,r,a,s,o
i=t(S.tfhd,new Uint8Array([0,0,0,58,(4278190080&e.id)>>24,(16711680&e.id)>>16,(65280&e.id)>>8,255&e.id,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0]))
s=Math.floor(e.baseMediaDecodeTime/j)
o=Math.floor(e.baseMediaDecodeTime%j)
n=t(S.tfdt,new Uint8Array([1,0,0,0,s>>>24&255,s>>>16&255,s>>>8&255,255&s,o>>>24&255,o>>>16&255,o>>>8&255,255&o]))
92
if("audio"===e.type){r=k(e,92)
return t(S.traf,i,n,r)}a=v(e)
r=k(e,a.length+92)
return t(S.traf,i,n,r,a)}
h=function(e){e.duration=e.duration||4294967295
return t(S.trak,p(e),f(e))}
T=function(e){var i=new Uint8Array([0,0,0,0,(4278190080&e.id)>>24,(16711680&e.id)>>16,(65280&e.id)>>8,255&e.id,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1])
"video"!==e.type&&(i[i.length-1]=0)
return t(S.trex,i)}
!function(){var e,i,n
n=function(e,t){var i=0,n=0,r=0,a=0
if(e.length){void 0!==e[0].duration&&(i=1)
void 0!==e[0].size&&(n=2)
void 0!==e[0].flags&&(r=4)
void 0!==e[0].compositionTimeOffset&&(a=8)}return[0,0,i|n|r|a,1,(4278190080&e.length)>>>24,(16711680&e.length)>>>16,(65280&e.length)>>>8,255&e.length,(4278190080&t)>>>24,(16711680&t)>>>16,(65280&t)>>>8,255&t]}
i=function(e,i){var r,a,s,o,u,l
i+=20+16*(o=e.samples||[]).length
s=n(o,i);(a=new Uint8Array(s.length+16*o.length)).set(s)
r=s.length
for(l=0;l<o.length;l++){u=o[l]
a[r++]=(4278190080&u.duration)>>>24
a[r++]=(16711680&u.duration)>>>16
a[r++]=(65280&u.duration)>>>8
a[r++]=255&u.duration
a[r++]=(4278190080&u.size)>>>24
a[r++]=(16711680&u.size)>>>16
a[r++]=(65280&u.size)>>>8
a[r++]=255&u.size
a[r++]=u.flags.isLeading<<2|u.flags.dependsOn
a[r++]=u.flags.isDependedOn<<6|u.flags.hasRedundancy<<4|u.flags.paddingValue<<1|u.flags.isNonSyncSample
a[r++]=61440&u.flags.degradationPriority
a[r++]=15&u.flags.degradationPriority
a[r++]=(4278190080&u.compositionTimeOffset)>>>24
a[r++]=(16711680&u.compositionTimeOffset)>>>16
a[r++]=(65280&u.compositionTimeOffset)>>>8
a[r++]=255&u.compositionTimeOffset}return t(S.trun,a)}
e=function(e,i){var r,a,s,o,u,l
i+=20+8*(o=e.samples||[]).length
s=n(o,i);(r=new Uint8Array(s.length+8*o.length)).set(s)
a=s.length
for(l=0;l<o.length;l++){u=o[l]
r[a++]=(4278190080&u.duration)>>>24
r[a++]=(16711680&u.duration)>>>16
r[a++]=(65280&u.duration)>>>8
r[a++]=255&u.duration
r[a++]=(4278190080&u.size)>>>24
r[a++]=(16711680&u.size)>>>16
r[a++]=(65280&u.size)>>>8
r[a++]=255&u.size}return t(S.trun,r)}
k=function(t,n){return"audio"===t.type?e(t,n):i(t,n)}}()
var V,H,q,W,G,z,X,K,Y=a,Q=u,$=function(e){var t,i=r(),n=l(e);(t=new Uint8Array(i.byteLength+n.byteLength)).set(i)
t.set(n,i.byteLength)
return t},J=function(e,t){var i={size:0,flags:{isLeading:0,dependsOn:1,isDependedOn:0,hasRedundancy:0,degradationPriority:0,isNonSyncSample:1}}
i.dataOffset=t
i.compositionTimeOffset=e.pts-e.dts
i.duration=e.duration
i.size=4*e.length
i.size+=e.byteLength
if(e.keyFrame){i.flags.dependsOn=2
i.flags.isNonSyncSample=0}return i},Z=function(e){var t,i,n=[],r=[]
r.byteLength=0
r.nalCount=0
r.duration=0
n.byteLength=0
for(t=0;t<e.length;t++)if("access_unit_delimiter_rbsp"===(i=e[t]).nalUnitType){if(n.length){n.duration=i.dts-n.dts
r.byteLength+=n.byteLength
r.nalCount+=n.length
r.duration+=n.duration
r.push(n)}(n=[i]).byteLength=i.data.byteLength
n.pts=i.pts
n.dts=i.dts}else{"slice_layer_without_partitioning_rbsp_idr"===i.nalUnitType&&(n.keyFrame=!0)
n.duration=i.dts-n.dts
n.byteLength+=i.data.byteLength
n.push(i)}r.length&&(!n.duration||n.duration<=0)&&(n.duration=r[r.length-1].duration)
r.byteLength+=n.byteLength
r.nalCount+=n.length
r.duration+=n.duration
r.push(n)
return r},ee=function(e){var t,i,n=[],r=[]
n.byteLength=0
n.nalCount=0
n.duration=0
n.pts=e[0].pts
n.dts=e[0].dts
r.byteLength=0
r.nalCount=0
r.duration=0
r.pts=e[0].pts
r.dts=e[0].dts
for(t=0;t<e.length;t++)if((i=e[t]).keyFrame){if(n.length){r.push(n)
r.byteLength+=n.byteLength
r.nalCount+=n.nalCount
r.duration+=n.duration}(n=[i]).nalCount=i.length
n.byteLength=i.byteLength
n.pts=i.pts
n.dts=i.dts
n.duration=i.duration}else{n.duration+=i.duration
n.nalCount+=i.length
n.byteLength+=i.byteLength
n.push(i)}r.length&&n.duration<=0&&(n.duration=r[r.length-1].duration)
r.byteLength+=n.byteLength
r.nalCount+=n.nalCount
r.duration+=n.duration
r.push(n)
return r},te=function(e){var t
if(!e[0][0].keyFrame&&e.length>1){t=e.shift()
e.byteLength-=t.byteLength
e.nalCount-=t.nalCount
e[0][0].dts=t.dts
e[0][0].pts=t.pts
e[0][0].duration+=t.duration}return e},ie=function(e,t){var i,n,r,a,s,o=t||0,u=[]
for(i=0;i<e.length;i++){a=e[i]
for(n=0;n<a.length;n++){s=a[n]
o+=(r=J(s,o)).size
u.push(r)}}return u},ne=function(e){var t,i,n,r,a,s,o=0,u=e.byteLength,l=e.nalCount,c=new Uint8Array(u+4*l),d=new DataView(c.buffer)
for(t=0;t<e.length;t++){r=e[t]
for(i=0;i<r.length;i++){a=r[i]
for(n=0;n<a.length;n++){s=a[n]
d.setUint32(o,s.data.byteLength)
o+=4
c.set(s.data,o)
o+=s.data.byteLength}}}return c},re=[33,16,5,32,164,27],ae=[33,65,108,84,1,2,4,8,168,2,4,8,17,191,252],se=function(e){for(var t=[];e--;)t.push(0)
return t},oe=function(){if(!V){var e={96e3:[re,[227,64],se(154),[56]],88200:[re,[231],se(170),[56]],64e3:[re,[248,192],se(240),[56]],48e3:[re,[255,192],se(268),[55,148,128],se(54),[112]],44100:[re,[255,192],se(268),[55,163,128],se(84),[112]],32e3:[re,[255,192],se(268),[55,234],se(226),[112]],24e3:[re,[255,192],se(268),[55,255,128],se(268),[111,112],se(126),[224]],16e3:[re,[255,192],se(268),[55,255,128],se(268),[111,255],se(269),[223,108],se(195),[1,192]],12e3:[ae,se(268),[3,127,248],se(268),[6,255,240],se(268),[13,255,224],se(268),[27,253,128],se(259),[56]],11025:[ae,se(268),[3,127,248],se(268),[6,255,240],se(268),[13,255,224],se(268),[27,255,192],se(268),[55,175,128],se(108),[112]],8e3:[ae,se(268),[3,121,16],se(47),[7]]}
V=(t=e,Object.keys(t).reduce((function(e,i){e[i]=new Uint8Array(t[i].reduce((function(e,t){return e.concat(t)}),[]))
return e}),{}))}var t
return V},ue=9e4
z=function(e,t){return H(G(e,t))}
X=function(e,t){return q(W(e),t)}
K=function(e,t,i){return W(i?e:e-t)}
var le=ue,ce=H=function(e){return e*ue},de=(q=function(e,t){return e*t},W=function(e){return e/ue}),he=(G=function(e,t){return e/t},z),pe=X,fe=K,me=function(e,t,i,n){var r,a,s,o,u,l=0,c=0,d=0
if(t.length){r=he(e.baseMediaDecodeTime,e.samplerate)
a=Math.ceil(le/(e.samplerate/1024))
if(i&&n){l=r-Math.max(i,n)
d=(c=Math.floor(l/a))*a}if(!(c<1||d>le/2)){(s=oe()[e.samplerate])||(s=t[0].data)
for(o=0;o<c;o++){u=t[0]
t.splice(0,0,{data:s,dts:u.dts-a,pts:u.pts-a})}e.baseMediaDecodeTime-=Math.floor(pe(d,e.samplerate))
return d}}},ge=function(e,t,i){if(t.minSegmentDts>=i)return e
t.minSegmentDts=1/0
return e.filter((function(e){if(e.dts>=i){t.minSegmentDts=Math.min(t.minSegmentDts,e.dts)
t.minSegmentPts=t.minSegmentDts
return!0}return!1}))},ve=function(e){var t,i,n=[]
for(t=0;t<e.length;t++){i=e[t]
n.push({size:i.data.byteLength,duration:1024})}return n},ye=function(e){var t,i,n=0,r=new Uint8Array(function(e){var t,i=0
for(t=0;t<e.length;t++)i+=e[t].data.byteLength
return i}(e))
for(t=0;t<e.length;t++){i=e[t]
r.set(i.data,n)
n+=i.data.byteLength}return r},_e=le,be=function(e){delete e.minSegmentDts
delete e.maxSegmentDts
delete e.minSegmentPts
delete e.maxSegmentPts},Te=function(e,t){var i,n=e.minSegmentDts
t||(n-=e.timelineStartInfo.dts)
i=e.timelineStartInfo.baseMediaDecodeTime
i+=n
i=Math.max(0,i)
if("audio"===e.type){i*=e.samplerate/_e
i=Math.floor(i)}return i},ke=function(e,t){if("number"==typeof t.pts){void 0===e.timelineStartInfo.pts&&(e.timelineStartInfo.pts=t.pts)
void 0===e.minSegmentPts?e.minSegmentPts=t.pts:e.minSegmentPts=Math.min(e.minSegmentPts,t.pts)
void 0===e.maxSegmentPts?e.maxSegmentPts=t.pts:e.maxSegmentPts=Math.max(e.maxSegmentPts,t.pts)}if("number"==typeof t.dts){void 0===e.timelineStartInfo.dts&&(e.timelineStartInfo.dts=t.dts)
void 0===e.minSegmentDts?e.minSegmentDts=t.dts:e.minSegmentDts=Math.min(e.minSegmentDts,t.dts)
void 0===e.maxSegmentDts?e.maxSegmentDts=t.dts:e.maxSegmentDts=Math.max(e.maxSegmentDts,t.dts)}},Se=function(e){for(var t=0,i={payloadType:-1,payloadSize:0},n=0,r=0;t<e.byteLength&&128!==e[t];){for(;255===e[t];){n+=255
t++}n+=e[t++]
for(;255===e[t];){r+=255
t++}r+=e[t++]
if(!i.payload&&4===n){if("GA94"===String.fromCharCode(e[t+3],e[t+4],e[t+5],e[t+6])){i.payloadType=n
i.payloadSize=r
i.payload=e.subarray(t,t+r)
break}i.payload=void 0}t+=r
n=0
r=0}return i},Ee=function(e){return 181!==e.payload[0]||49!=(e.payload[1]<<8|e.payload[2])||"GA94"!==String.fromCharCode(e.payload[3],e.payload[4],e.payload[5],e.payload[6])||3!==e.payload[7]?null:e.payload.subarray(8,e.payload.length-1)},Ce=function(e,t){var i,n,r,a,s=[]
if(!(64&t[0]))return s
n=31&t[0]
for(i=0;i<n;i++){a={type:3&t[(r=3*i)+2],pts:e}
if(4&t[r+2]){a.ccData=t[r+3]<<8|t[r+4]
s.push(a)}}return s},we=function(e){for(var t,i,n=e.byteLength,r=[],a=1;a<n-2;)if(0===e[a]&&0===e[a+1]&&3===e[a+2]){r.push(a+2)
a+=2}else a++
if(0===r.length)return e
t=n-r.length
i=new Uint8Array(t)
var s=0
for(a=0;a<t;s++,a++){if(s===r[0]){s++
r.shift()}i[a]=e[s]}return i},Ie=4,Pe=function e(t){t=t||{}
e.prototype.init.call(this)
this.parse708captions_="boolean"!=typeof t.parse708captions||t.parse708captions
this.captionPackets_=[]
this.ccStreams_=[new Be(0,0),new Be(0,1),new Be(1,0),new Be(1,1)]
this.parse708captions_&&(this.cc708Stream_=new De({captionServices:t.captionServices}))
this.reset()
this.ccStreams_.forEach((function(e){e.on("data",this.trigger.bind(this,"data"))
e.on("partialdone",this.trigger.bind(this,"partialdone"))
e.on("done",this.trigger.bind(this,"done"))}),this)
if(this.parse708captions_){this.cc708Stream_.on("data",this.trigger.bind(this,"data"))
this.cc708Stream_.on("partialdone",this.trigger.bind(this,"partialdone"))
this.cc708Stream_.on("done",this.trigger.bind(this,"done"))}};(Pe.prototype=new U).push=function(e){var t,i,n
if("sei_rbsp"===e.nalUnitType&&(t=Se(e.escapedRBSP)).payload&&t.payloadType===Ie&&(i=Ee(t)))if(e.dts<this.latestDts_)this.ignoreNextEqualDts_=!0
else if(e.dts===this.latestDts_&&this.ignoreNextEqualDts_){this.numSameDts_--
this.numSameDts_||(this.ignoreNextEqualDts_=!1)}else{n=Ce(e.pts,i)
this.captionPackets_=this.captionPackets_.concat(n)
this.latestDts_!==e.dts&&(this.numSameDts_=0)
this.numSameDts_++
this.latestDts_=e.dts}}
Pe.prototype.flushCCStreams=function(e){this.ccStreams_.forEach((function(t){return"flush"===e?t.flush():t.partialFlush()}),this)}
Pe.prototype.flushStream=function(e){if(this.captionPackets_.length){this.captionPackets_.forEach((function(e,t){e.presortIndex=t}))
this.captionPackets_.sort((function(e,t){return e.pts===t.pts?e.presortIndex-t.presortIndex:e.pts-t.pts}))
this.captionPackets_.forEach((function(e){e.type<2?this.dispatchCea608Packet(e):this.dispatchCea708Packet(e)}),this)
this.captionPackets_.length=0
this.flushCCStreams(e)}else this.flushCCStreams(e)}
Pe.prototype.flush=function(){return this.flushStream("flush")}
Pe.prototype.partialFlush=function(){return this.flushStream("partialFlush")}
Pe.prototype.reset=function(){this.latestDts_=null
this.ignoreNextEqualDts_=!1
this.numSameDts_=0
this.activeCea608Channel_=[null,null]
this.ccStreams_.forEach((function(e){e.reset()}))}
Pe.prototype.dispatchCea608Packet=function(e){this.setsTextOrXDSActive(e)?this.activeCea608Channel_[e.type]=null:this.setsChannel1Active(e)?this.activeCea608Channel_[e.type]=0:this.setsChannel2Active(e)&&(this.activeCea608Channel_[e.type]=1)
null!==this.activeCea608Channel_[e.type]&&this.ccStreams_[(e.type<<1)+this.activeCea608Channel_[e.type]].push(e)}
Pe.prototype.setsChannel1Active=function(e){return 4096==(30720&e.ccData)}
Pe.prototype.setsChannel2Active=function(e){return 6144==(30720&e.ccData)}
Pe.prototype.setsTextOrXDSActive=function(e){return 256==(28928&e.ccData)||4138==(30974&e.ccData)||6186==(30974&e.ccData)}
Pe.prototype.dispatchCea708Packet=function(e){this.parse708captions_&&this.cc708Stream_.push(e)}
var xe={127:9834,4128:32,4129:160,4133:8230,4138:352,4140:338,4144:9608,4145:8216,4146:8217,4147:8220,4148:8221,4149:8226,4153:8482,4154:353,4156:339,4157:8480,4159:376,4214:8539,4215:8540,4216:8541,4217:8542,4218:9168,4219:9124,4220:9123,4221:9135,4222:9126,4223:9121,4256:12600},Ae=function(e){return 32<=e&&e<=127||160<=e&&e<=255},Oe=function(e){this.windowNum=e
this.reset()}
Oe.prototype.reset=function(){this.clearText()
this.pendingNewLine=!1
this.winAttr={}
this.penAttr={}
this.penLoc={}
this.penColor={}
this.visible=0
this.rowLock=0
this.columnLock=0
this.priority=0
this.relativePositioning=0
this.anchorVertical=0
this.anchorHorizontal=0
this.anchorPoint=0
this.rowCount=1
this.virtualRowCount=this.rowCount+1
this.columnCount=41
this.windowStyle=0
this.penStyle=0}
Oe.prototype.getText=function(){return this.rows.join("\n")}
Oe.prototype.clearText=function(){this.rows=[""]
this.rowIdx=0}
Oe.prototype.newLine=function(e){this.rows.length>=this.virtualRowCount&&"function"==typeof this.beforeRowOverflow&&this.beforeRowOverflow(e)
if(this.rows.length>0){this.rows.push("")
this.rowIdx++}for(;this.rows.length>this.virtualRowCount;){this.rows.shift()
this.rowIdx--}}
Oe.prototype.isEmpty=function(){return 0===this.rows.length||1===this.rows.length&&""===this.rows[0]}
Oe.prototype.addText=function(e){this.rows[this.rowIdx]+=e}
Oe.prototype.backspace=function(){if(!this.isEmpty()){var e=this.rows[this.rowIdx]
this.rows[this.rowIdx]=e.substr(0,e.length-1)}}
var Le=function(e,t,i){this.serviceNum=e
this.text=""
this.currentWindow=new Oe(-1)
this.windows=[]
this.stream=i
"string"==typeof t&&this.createTextDecoder(t)}
Le.prototype.init=function(e,t){this.startPts=e
for(var i=0;i<8;i++){this.windows[i]=new Oe(i)
"function"==typeof t&&(this.windows[i].beforeRowOverflow=t)}}
Le.prototype.setCurrentWindow=function(e){this.currentWindow=this.windows[e]}
Le.prototype.createTextDecoder=function(e){if("undefined"==typeof TextDecoder)this.stream.trigger("log",{level:"warn",message:"The `encoding` option is unsupported without TextDecoder support"})
else try{this.textDecoder_=new TextDecoder(e)}catch(t){this.stream.trigger("log",{level:"warn",message:"TextDecoder could not be created with "+e+" encoding. "+t})}}
var De=function e(t){t=t||{}
e.prototype.init.call(this)
var i,n=this,r=t.captionServices||{},a={}
Object.keys(r).forEach((function(e){i=r[e];/^SERVICE/.test(e)&&(a[e]=i.encoding)}))
this.serviceEncodings=a
this.current708Packet=null
this.services={}
this.push=function(e){if(3===e.type){n.new708Packet()
n.add708Bytes(e)}else{null===n.current708Packet&&n.new708Packet()
n.add708Bytes(e)}}}
De.prototype=new U
De.prototype.new708Packet=function(){null!==this.current708Packet&&this.push708Packet()
this.current708Packet={data:[],ptsVals:[]}}
De.prototype.add708Bytes=function(e){var t=e.ccData,i=t>>>8,n=255&t
this.current708Packet.ptsVals.push(e.pts)
this.current708Packet.data.push(i)
this.current708Packet.data.push(n)}
De.prototype.push708Packet=function(){var e=this.current708Packet,t=e.data,i=null,n=null,r=0,a=t[r++]
e.seq=a>>6
e.sizeCode=63&a
for(;r<t.length;r++){n=31&(a=t[r++])
7===(i=a>>5)&&n>0&&(i=a=t[r++])
this.pushServiceBlock(i,r,n)
n>0&&(r+=n-1)}}
De.prototype.pushServiceBlock=function(e,t,i){var n,r=t,a=this.current708Packet.data,s=this.services[e]
s||(s=this.initService(e,r))
for(;r<t+i&&r<a.length;r++){n=a[r]
Ae(n)?r=this.handleText(r,s):24===n?r=this.multiByteCharacter(r,s):16===n?r=this.extendedCommands(r,s):128<=n&&n<=135?r=this.setCurrentWindow(r,s):152<=n&&n<=159?r=this.defineWindow(r,s):136===n?r=this.clearWindows(r,s):140===n?r=this.deleteWindows(r,s):137===n?r=this.displayWindows(r,s):138===n?r=this.hideWindows(r,s):139===n?r=this.toggleWindows(r,s):151===n?r=this.setWindowAttributes(r,s):144===n?r=this.setPenAttributes(r,s):145===n?r=this.setPenColor(r,s):146===n?r=this.setPenLocation(r,s):143===n?s=this.reset(r,s):8===n?s.currentWindow.backspace():12===n?s.currentWindow.clearText():13===n?s.currentWindow.pendingNewLine=!0:14===n?s.currentWindow.clearText():141===n&&r++}}
De.prototype.extendedCommands=function(e,t){var i=this.current708Packet.data[++e]
Ae(i)&&(e=this.handleText(e,t,{isExtended:!0}))
return e}
De.prototype.getPts=function(e){return this.current708Packet.ptsVals[Math.floor(e/2)]}
De.prototype.initService=function(e,t){var i,n,r=this;(i="SERVICE"+e)in this.serviceEncodings&&(n=this.serviceEncodings[i])
this.services[e]=new Le(e,n,r)
this.services[e].init(this.getPts(t),(function(t){r.flushDisplayed(t,r.services[e])}))
return this.services[e]}
De.prototype.handleText=function(e,t,i){var n,r,a,s,o=i&&i.isExtended,u=i&&i.isMultiByte,l=this.current708Packet.data,c=o?4096:0,d=l[e],h=l[e+1],p=t.currentWindow
if(t.textDecoder_&&!o){if(u){r=[d,h]
e++}else r=[d]
n=t.textDecoder_.decode(new Uint8Array(r))}else n=(s=xe[a=c|d]||a,4096&a&&a===s?"":String.fromCharCode(s))
p.pendingNewLine&&!p.isEmpty()&&p.newLine(this.getPts(e))
p.pendingNewLine=!1
p.addText(n)
return e}
De.prototype.multiByteCharacter=function(e,t){var i=this.current708Packet.data,n=i[e+1],r=i[e+2]
Ae(n)&&Ae(r)&&(e=this.handleText(++e,t,{isMultiByte:!0}))
return e}
De.prototype.setCurrentWindow=function(e,t){var i=7&this.current708Packet.data[e]
t.setCurrentWindow(i)
return e}
De.prototype.defineWindow=function(e,t){var i=this.current708Packet.data,n=i[e],r=7&n
t.setCurrentWindow(r)
var a=t.currentWindow
n=i[++e]
a.visible=(32&n)>>5
a.rowLock=(16&n)>>4
a.columnLock=(8&n)>>3
a.priority=7&n
n=i[++e]
a.relativePositioning=(128&n)>>7
a.anchorVertical=127&n
n=i[++e]
a.anchorHorizontal=n
n=i[++e]
a.anchorPoint=(240&n)>>4
a.rowCount=15&n
n=i[++e]
a.columnCount=63&n
n=i[++e]
a.windowStyle=(56&n)>>3
a.penStyle=7&n
a.virtualRowCount=a.rowCount+1
return e}
De.prototype.setWindowAttributes=function(e,t){var i=this.current708Packet.data,n=i[e],r=t.currentWindow.winAttr
n=i[++e]
r.fillOpacity=(192&n)>>6
r.fillRed=(48&n)>>4
r.fillGreen=(12&n)>>2
r.fillBlue=3&n
n=i[++e]
r.borderType=(192&n)>>6
r.borderRed=(48&n)>>4
r.borderGreen=(12&n)>>2
r.borderBlue=3&n
n=i[++e]
r.borderType+=(128&n)>>5
r.wordWrap=(64&n)>>6
r.printDirection=(48&n)>>4
r.scrollDirection=(12&n)>>2
r.justify=3&n
n=i[++e]
r.effectSpeed=(240&n)>>4
r.effectDirection=(12&n)>>2
r.displayEffect=3&n
return e}
De.prototype.flushDisplayed=function(e,t){for(var i=[],n=0;n<8;n++)t.windows[n].visible&&!t.windows[n].isEmpty()&&i.push(t.windows[n].getText())
t.endPts=e
t.text=i.join("\n\n")
this.pushCaption(t)
t.startPts=e}
De.prototype.pushCaption=function(e){if(""!==e.text){this.trigger("data",{startPts:e.startPts,endPts:e.endPts,text:e.text,stream:"cc708_"+e.serviceNum})
e.text=""
e.startPts=e.endPts}}
De.prototype.displayWindows=function(e,t){var i=this.current708Packet.data[++e],n=this.getPts(e)
this.flushDisplayed(n,t)
for(var r=0;r<8;r++)i&1<<r&&(t.windows[r].visible=1)
return e}
De.prototype.hideWindows=function(e,t){var i=this.current708Packet.data[++e],n=this.getPts(e)
this.flushDisplayed(n,t)
for(var r=0;r<8;r++)i&1<<r&&(t.windows[r].visible=0)
return e}
De.prototype.toggleWindows=function(e,t){var i=this.current708Packet.data[++e],n=this.getPts(e)
this.flushDisplayed(n,t)
for(var r=0;r<8;r++)i&1<<r&&(t.windows[r].visible^=1)
return e}
De.prototype.clearWindows=function(e,t){var i=this.current708Packet.data[++e],n=this.getPts(e)
this.flushDisplayed(n,t)
for(var r=0;r<8;r++)i&1<<r&&t.windows[r].clearText()
return e}
De.prototype.deleteWindows=function(e,t){var i=this.current708Packet.data[++e],n=this.getPts(e)
this.flushDisplayed(n,t)
for(var r=0;r<8;r++)i&1<<r&&t.windows[r].reset()
return e}
De.prototype.setPenAttributes=function(e,t){var i=this.current708Packet.data,n=i[e],r=t.currentWindow.penAttr
n=i[++e]
r.textTag=(240&n)>>4
r.offset=(12&n)>>2
r.penSize=3&n
n=i[++e]
r.italics=(128&n)>>7
r.underline=(64&n)>>6
r.edgeType=(56&n)>>3
r.fontStyle=7&n
return e}
De.prototype.setPenColor=function(e,t){var i=this.current708Packet.data,n=i[e],r=t.currentWindow.penColor
n=i[++e]
r.fgOpacity=(192&n)>>6
r.fgRed=(48&n)>>4
r.fgGreen=(12&n)>>2
r.fgBlue=3&n
n=i[++e]
r.bgOpacity=(192&n)>>6
r.bgRed=(48&n)>>4
r.bgGreen=(12&n)>>2
r.bgBlue=3&n
n=i[++e]
r.edgeRed=(48&n)>>4
r.edgeGreen=(12&n)>>2
r.edgeBlue=3&n
return e}
De.prototype.setPenLocation=function(e,t){var i=this.current708Packet.data,n=i[e],r=t.currentWindow.penLoc
t.currentWindow.pendingNewLine=!0
n=i[++e]
r.row=15&n
n=i[++e]
r.column=63&n
return e}
De.prototype.reset=function(e,t){var i=this.getPts(e)
this.flushDisplayed(i,t)
return this.initService(t.serviceNum,e)}
var Re={42:225,92:233,94:237,95:243,96:250,123:231,124:247,125:209,126:241,127:9608,304:174,305:176,306:189,307:191,308:8482,309:162,310:163,311:9834,312:224,313:160,314:232,315:226,316:234,317:238,318:244,319:251,544:193,545:201,546:211,547:218,548:220,549:252,550:8216,551:161,552:42,553:39,554:8212,555:169,556:8480,557:8226,558:8220,559:8221,560:192,561:194,562:199,563:200,564:202,565:203,566:235,567:206,568:207,569:239,570:212,571:217,572:249,573:219,574:171,575:187,800:195,801:227,802:205,803:204,804:236,805:210,806:242,807:213,808:245,809:123,810:125,811:92,812:94,813:95,814:124,815:126,816:196,817:228,818:214,819:246,820:223,821:165,822:164,823:9474,824:197,825:229,826:216,827:248,828:9484,829:9488,830:9492,831:9496},Me=function(e){if(null===e)return""
e=Re[e]||e
return String.fromCharCode(e)},Ne=[4352,4384,4608,4640,5376,5408,5632,5664,5888,5920,4096,4864,4896,5120,5152],Ue=function(){for(var e=[],t=15;t--;)e.push("")
return e},Be=function e(t,i){e.prototype.init.call(this)
this.field_=t||0
this.dataChannel_=i||0
this.name_="CC"+(1+(this.field_<<1|this.dataChannel_))
this.setConstants()
this.reset()
this.push=function(e){var t,i,n,r,a
if((t=32639&e.ccData)!==this.lastControlCode_){4096==(61440&t)?this.lastControlCode_=t:t!==this.PADDING_&&(this.lastControlCode_=null)
n=t>>>8
r=255&t
if(t!==this.PADDING_)if(t===this.RESUME_CAPTION_LOADING_)this.mode_="popOn"
else if(t===this.END_OF_CAPTION_){this.mode_="popOn"
this.clearFormatting(e.pts)
this.flushDisplayed(e.pts)
i=this.displayed_
this.displayed_=this.nonDisplayed_
this.nonDisplayed_=i
this.startPts_=e.pts}else if(t===this.ROLL_UP_2_ROWS_){this.rollUpRows_=2
this.setRollUp(e.pts)}else if(t===this.ROLL_UP_3_ROWS_){this.rollUpRows_=3
this.setRollUp(e.pts)}else if(t===this.ROLL_UP_4_ROWS_){this.rollUpRows_=4
this.setRollUp(e.pts)}else if(t===this.CARRIAGE_RETURN_){this.clearFormatting(e.pts)
this.flushDisplayed(e.pts)
this.shiftRowsUp_()
this.startPts_=e.pts}else if(t===this.BACKSPACE_)"popOn"===this.mode_?this.nonDisplayed_[this.row_]=this.nonDisplayed_[this.row_].slice(0,-1):this.displayed_[this.row_]=this.displayed_[this.row_].slice(0,-1)
else if(t===this.ERASE_DISPLAYED_MEMORY_){this.flushDisplayed(e.pts)
this.displayed_=Ue()}else if(t===this.ERASE_NON_DISPLAYED_MEMORY_)this.nonDisplayed_=Ue()
else if(t===this.RESUME_DIRECT_CAPTIONING_){if("paintOn"!==this.mode_){this.flushDisplayed(e.pts)
this.displayed_=Ue()}this.mode_="paintOn"
this.startPts_=e.pts}else if(this.isSpecialCharacter(n,r)){a=Me((n=(3&n)<<8)|r)
this[this.mode_](e.pts,a)
this.column_++}else if(this.isExtCharacter(n,r)){"popOn"===this.mode_?this.nonDisplayed_[this.row_]=this.nonDisplayed_[this.row_].slice(0,-1):this.displayed_[this.row_]=this.displayed_[this.row_].slice(0,-1)
a=Me((n=(3&n)<<8)|r)
this[this.mode_](e.pts,a)
this.column_++}else if(this.isMidRowCode(n,r)){this.clearFormatting(e.pts)
this[this.mode_](e.pts," ")
this.column_++
14==(14&r)&&this.addFormatting(e.pts,["i"])
1==(1&r)&&this.addFormatting(e.pts,["u"])}else if(this.isOffsetControlCode(n,r))this.column_+=3&r
else if(this.isPAC(n,r)){var s=Ne.indexOf(7968&t)
if("rollUp"===this.mode_){s-this.rollUpRows_+1<0&&(s=this.rollUpRows_-1)
this.setRollUp(e.pts,s)}if(s!==this.row_){this.clearFormatting(e.pts)
this.row_=s}1&r&&-1===this.formatting_.indexOf("u")&&this.addFormatting(e.pts,["u"])
16==(16&t)&&(this.column_=4*((14&t)>>1))
this.isColorPAC(r)&&14==(14&r)&&this.addFormatting(e.pts,["i"])}else if(this.isNormalChar(n)){0===r&&(r=null)
a=Me(n)
a+=Me(r)
this[this.mode_](e.pts,a)
this.column_+=a.length}}else this.lastControlCode_=null}}
Be.prototype=new U
Be.prototype.flushDisplayed=function(e){var t=this.displayed_.map((function(e,t){try{return e.trim()}catch(e){this.trigger("log",{level:"warn",message:"Skipping a malformed 608 caption at index "+t+"."})
return""}}),this).join("\n").replace(/^\n+|\n+$/g,"")
t.length&&this.trigger("data",{startPts:this.startPts_,endPts:e,text:t,stream:this.name_})}
Be.prototype.reset=function(){this.mode_="popOn"
this.topRow_=0
this.startPts_=0
this.displayed_=Ue()
this.nonDisplayed_=Ue()
this.lastControlCode_=null
this.column_=0
this.row_=14
this.rollUpRows_=2
this.formatting_=[]}
Be.prototype.setConstants=function(){if(0===this.dataChannel_){this.BASE_=16
this.EXT_=17
this.CONTROL_=(20|this.field_)<<8
this.OFFSET_=23}else if(1===this.dataChannel_){this.BASE_=24
this.EXT_=25
this.CONTROL_=(28|this.field_)<<8
this.OFFSET_=31}this.PADDING_=0
this.RESUME_CAPTION_LOADING_=32|this.CONTROL_
this.END_OF_CAPTION_=47|this.CONTROL_
this.ROLL_UP_2_ROWS_=37|this.CONTROL_
this.ROLL_UP_3_ROWS_=38|this.CONTROL_
this.ROLL_UP_4_ROWS_=39|this.CONTROL_
this.CARRIAGE_RETURN_=45|this.CONTROL_
this.RESUME_DIRECT_CAPTIONING_=41|this.CONTROL_
this.BACKSPACE_=33|this.CONTROL_
this.ERASE_DISPLAYED_MEMORY_=44|this.CONTROL_
this.ERASE_NON_DISPLAYED_MEMORY_=46|this.CONTROL_}
Be.prototype.isSpecialCharacter=function(e,t){return e===this.EXT_&&t>=48&&t<=63}
Be.prototype.isExtCharacter=function(e,t){return(e===this.EXT_+1||e===this.EXT_+2)&&t>=32&&t<=63}
Be.prototype.isMidRowCode=function(e,t){return e===this.EXT_&&t>=32&&t<=47}
Be.prototype.isOffsetControlCode=function(e,t){return e===this.OFFSET_&&t>=33&&t<=35}
Be.prototype.isPAC=function(e,t){return e>=this.BASE_&&e<this.BASE_+8&&t>=64&&t<=127}
Be.prototype.isColorPAC=function(e){return e>=64&&e<=79||e>=96&&e<=127}
Be.prototype.isNormalChar=function(e){return e>=32&&e<=127}
Be.prototype.setRollUp=function(e,t){if("rollUp"!==this.mode_){this.row_=14
this.mode_="rollUp"
this.flushDisplayed(e)
this.nonDisplayed_=Ue()
this.displayed_=Ue()}if(void 0!==t&&t!==this.row_)for(var i=0;i<this.rollUpRows_;i++){this.displayed_[t-i]=this.displayed_[this.row_-i]
this.displayed_[this.row_-i]=""}void 0===t&&(t=this.row_)
this.topRow_=t-this.rollUpRows_+1}
Be.prototype.addFormatting=function(e,t){this.formatting_=this.formatting_.concat(t)
var i=t.reduce((function(e,t){return e+"<"+t+">"}),"")
this[this.mode_](e,i)}
Be.prototype.clearFormatting=function(e){if(this.formatting_.length){var t=this.formatting_.reverse().reduce((function(e,t){return e+"</"+t+">"}),"")
this.formatting_=[]
this[this.mode_](e,t)}}
Be.prototype.popOn=function(e,t){var i=this.nonDisplayed_[this.row_]
i+=t
this.nonDisplayed_[this.row_]=i}
Be.prototype.rollUp=function(e,t){var i=this.displayed_[this.row_]
i+=t
this.displayed_[this.row_]=i}
Be.prototype.shiftRowsUp_=function(){var e
for(e=0;e<this.topRow_;e++)this.displayed_[e]=""
for(e=this.row_+1;e<15;e++)this.displayed_[e]=""
for(e=this.topRow_;e<this.row_;e++)this.displayed_[e]=this.displayed_[e+1]
this.displayed_[this.row_]=""}
Be.prototype.paintOn=function(e,t){var i=this.displayed_[this.row_]
i+=t
this.displayed_[this.row_]=i}
var Fe={CaptionStream:Pe,Cea608Stream:Be,Cea708Stream:De},je={H264_STREAM_TYPE:27,ADTS_STREAM_TYPE:15,METADATA_STREAM_TYPE:21},Ve="shared",He=function(e,t){var i=1
e>t&&(i=-1)
for(;Math.abs(t-e)>4294967296;)e+=8589934592*i
return e},qe=function e(t){var i,n
e.prototype.init.call(this)
this.type_=t||Ve
this.push=function(e){if(this.type_===Ve||e.type===this.type_){void 0===n&&(n=e.dts)
e.dts=He(e.dts,n)
e.pts=He(e.pts,n)
i=e.dts
this.trigger("data",e)}}
this.flush=function(){n=i
this.trigger("done")}
this.endTimeline=function(){this.flush()
this.trigger("endedtimeline")}
this.discontinuity=function(){n=void 0
i=void 0}
this.reset=function(){this.discontinuity()
this.trigger("reset")}}
qe.prototype=new U
var We,Ge=qe,ze=He,Xe=function(e,t,i){var n,r=""
for(n=t;n<i;n++)r+="%"+("00"+e[n].toString(16)).slice(-2)
return r},Ke=function(e,t,i){return decodeURIComponent(Xe(e,t,i))},Ye=function(e){return e[0]<<21|e[1]<<14|e[2]<<7|e[3]},Qe={TXXX:function(e){var t
if(3===e.data[0]){for(t=1;t<e.data.length;t++)if(0===e.data[t]){e.description=Ke(e.data,1,t)
e.value=Ke(e.data,t+1,e.data.length).replace(/\0*$/,"")
break}e.data=e.value}},WXXX:function(e){var t
if(3===e.data[0])for(t=1;t<e.data.length;t++)if(0===e.data[t]){e.description=Ke(e.data,1,t)
e.url=Ke(e.data,t+1,e.data.length)
break}},PRIV:function(e){var t,i
for(t=0;t<e.data.length;t++)if(0===e.data[t]){e.owner=(i=e.data,unescape(Xe(i,0,t)))
break}e.privateData=e.data.subarray(t+1)
e.data=e.privateData}}
We=function(e){var t,i={descriptor:e&&e.descriptor},n=0,r=[],a=0
We.prototype.init.call(this)
this.dispatchType=je.METADATA_STREAM_TYPE.toString(16)
if(i.descriptor)for(t=0;t<i.descriptor.length;t++)this.dispatchType+=("00"+i.descriptor[t].toString(16)).slice(-2)
this.push=function(e){var t,i,s,o,u
if("timed-metadata"===e.type){if(e.dataAlignmentIndicator){a=0
r.length=0}if(0===r.length&&(e.data.length<10||e.data[0]!=="I".charCodeAt(0)||e.data[1]!=="D".charCodeAt(0)||e.data[2]!=="3".charCodeAt(0)))this.trigger("log",{level:"warn",message:"Skipping unrecognized metadata packet"})
else{r.push(e)
a+=e.data.byteLength
if(1===r.length){n=Ye(e.data.subarray(6,10))
n+=10}if(!(a<n)){t={data:new Uint8Array(n),frames:[],pts:r[0].pts,dts:r[0].dts}
for(u=0;u<n;){t.data.set(r[0].data.subarray(0,n-u),u)
u+=r[0].data.byteLength
a-=r[0].data.byteLength
r.shift()}i=10
if(64&t.data[5]){i+=4
i+=Ye(t.data.subarray(10,14))
n-=Ye(t.data.subarray(16,20))}do{if((s=Ye(t.data.subarray(i+4,i+8)))<1){this.trigger("log",{level:"warn",message:"Malformed ID3 frame encountered. Skipping metadata parsing."})
return}(o={id:String.fromCharCode(t.data[i],t.data[i+1],t.data[i+2],t.data[i+3]),data:t.data.subarray(i+10,i+s+10)}).key=o.id
if(Qe[o.id]){Qe[o.id](o)
if("com.apple.streaming.transportStreamTimestamp"===o.owner){var l=o.data,c=(1&l[3])<<30|l[4]<<22|l[5]<<14|l[6]<<6|l[7]>>>2
c*=4
c+=3&l[7]
o.timeStamp=c
if(void 0===t.pts&&void 0===t.dts){t.pts=o.timeStamp
t.dts=o.timeStamp}this.trigger("timestamp",o)}}t.frames.push(o)
i+=10
i+=s}while(i<n)
this.trigger("data",t)}}}}}
We.prototype=new U
var $e,Je,Ze,et=We,tt=Ge,it=188;($e=function(){var e=new Uint8Array(it),t=0
$e.prototype.init.call(this)
this.push=function(i){var n,r=0,a=it
if(t){(n=new Uint8Array(i.byteLength+t)).set(e.subarray(0,t))
n.set(i,t)
t=0}else n=i
for(;a<n.byteLength;)if(71!==n[r]||71!==n[a]){r++
a++}else{this.trigger("data",n.subarray(r,a))
r+=it
a+=it}if(r<n.byteLength){e.set(n.subarray(r),0)
t=n.byteLength-r}}
this.flush=function(){if(t===it&&71===e[0]){this.trigger("data",e)
t=0}this.trigger("done")}
this.endTimeline=function(){this.flush()
this.trigger("endedtimeline")}
this.reset=function(){t=0
this.trigger("reset")}}).prototype=new U
Je=function(){var e,t,i,n
Je.prototype.init.call(this)
n=this
this.packetsWaitingForPmt=[]
this.programMapTable=void 0
e=function(e,n){var r=0
n.payloadUnitStartIndicator&&(r+=e[r]+1)
"pat"===n.type?t(e.subarray(r),n):i(e.subarray(r),n)}
t=function(e,t){t.section_number=e[7]
t.last_section_number=e[8]
n.pmtPid=(31&e[10])<<8|e[11]
t.pmtPid=n.pmtPid}
i=function(e,t){var i,r
if(1&e[5]){n.programMapTable={video:null,audio:null,"timed-metadata":{}}
i=3+((15&e[1])<<8|e[2])-4
r=12+((15&e[10])<<8|e[11])
for(;r<i;){var a=e[r],s=(31&e[r+1])<<8|e[r+2]
a===je.H264_STREAM_TYPE&&null===n.programMapTable.video?n.programMapTable.video=s:a===je.ADTS_STREAM_TYPE&&null===n.programMapTable.audio?n.programMapTable.audio=s:a===je.METADATA_STREAM_TYPE&&(n.programMapTable["timed-metadata"][s]=a)
r+=5+((15&e[r+3])<<8|e[r+4])}t.programMapTable=n.programMapTable}}
this.push=function(t){var i={},n=4
i.payloadUnitStartIndicator=!!(64&t[1])
i.pid=31&t[1]
i.pid<<=8
i.pid|=t[2];(48&t[3])>>>4>1&&(n+=t[n]+1)
if(0===i.pid){i.type="pat"
e(t.subarray(n),i)
this.trigger("data",i)}else if(i.pid===this.pmtPid){i.type="pmt"
e(t.subarray(n),i)
this.trigger("data",i)
for(;this.packetsWaitingForPmt.length;)this.processPes_.apply(this,this.packetsWaitingForPmt.shift())}else void 0===this.programMapTable?this.packetsWaitingForPmt.push([t,n,i]):this.processPes_(t,n,i)}
this.processPes_=function(e,t,i){i.pid===this.programMapTable.video?i.streamType=je.H264_STREAM_TYPE:i.pid===this.programMapTable.audio?i.streamType=je.ADTS_STREAM_TYPE:i.streamType=this.programMapTable["timed-metadata"][i.pid]
i.type="pes"
i.data=e.subarray(t)
this.trigger("data",i)}}
Je.prototype=new U
Je.STREAM_TYPES={h264:27,adts:15}
Ze=function(){var e,t=this,i=!1,n={data:[],size:0},r={data:[],size:0},a={data:[],size:0},s=function(e,i,n){var r,a,s=new Uint8Array(e.size),o={type:i},u=0,l=0
if(e.data.length&&!(e.size<9)){o.trackId=e.data[0].pid
for(u=0;u<e.data.length;u++){a=e.data[u]
s.set(a.data,l)
l+=a.data.byteLength}!function(e,t){var i,n=e[0]<<16|e[1]<<8|e[2]
t.data=new Uint8Array
if(1===n){t.packetLength=6+(e[4]<<8|e[5])
t.dataAlignmentIndicator=0!=(4&e[6])
if(192&(i=e[7])){t.pts=(14&e[9])<<27|(255&e[10])<<20|(254&e[11])<<12|(255&e[12])<<5|(254&e[13])>>>3
t.pts*=4
t.pts+=(6&e[13])>>>1
t.dts=t.pts
if(64&i){t.dts=(14&e[14])<<27|(255&e[15])<<20|(254&e[16])<<12|(255&e[17])<<5|(254&e[18])>>>3
t.dts*=4
t.dts+=(6&e[18])>>>1}}t.data=e.subarray(9+e[8])}}(s,o)
r="video"===i||o.packetLength<=e.size
if(n||r){e.size=0
e.data.length=0}r&&t.trigger("data",o)}}
Ze.prototype.init.call(this)
this.push=function(o){({pat:function(){},pes:function(){var e,t
switch(o.streamType){case je.H264_STREAM_TYPE:e=n
t="video"
break
case je.ADTS_STREAM_TYPE:e=r
t="audio"
break
case je.METADATA_STREAM_TYPE:e=a
t="timed-metadata"
break
default:return}o.payloadUnitStartIndicator&&s(e,t,!0)
e.data.push(o)
e.size+=o.data.byteLength},pmt:function(){var n={type:"metadata",tracks:[]}
null!==(e=o.programMapTable).video&&n.tracks.push({timelineStartInfo:{baseMediaDecodeTime:0},id:+e.video,codec:"avc",type:"video"})
null!==e.audio&&n.tracks.push({timelineStartInfo:{baseMediaDecodeTime:0},id:+e.audio,codec:"adts",type:"audio"})
i=!0
t.trigger("data",n)}})[o.type]()}
this.reset=function(){n.size=0
n.data.length=0
r.size=0
r.data.length=0
this.trigger("reset")}
this.flushStreams_=function(){s(n,"video")
s(r,"audio")
s(a,"timed-metadata")}
this.flush=function(){if(!i&&e){var n={type:"metadata",tracks:[]}
null!==e.video&&n.tracks.push({timelineStartInfo:{baseMediaDecodeTime:0},id:+e.video,codec:"avc",type:"video"})
null!==e.audio&&n.tracks.push({timelineStartInfo:{baseMediaDecodeTime:0},id:+e.audio,codec:"adts",type:"audio"})
t.trigger("data",n)}i=!1
this.flushStreams_()
this.trigger("done")}}
Ze.prototype=new U
var nt={PAT_PID:0,MP2T_PACKET_LENGTH:it,TransportPacketStream:$e,TransportParseStream:Je,ElementaryStream:Ze,TimestampRolloverStream:tt,CaptionStream:Fe.CaptionStream,Cea608Stream:Fe.Cea608Stream,Cea708Stream:Fe.Cea708Stream,MetadataStream:et}
for(var rt in je)je.hasOwnProperty(rt)&&(nt[rt]=je[rt])
var at,st=nt,ot=le,ut=[96e3,88200,64e3,48e3,44100,32e3,24e3,22050,16e3,12e3,11025,8e3,7350]
at=function(e){var t,i=0
at.prototype.init.call(this)
this.skipWarn_=function(e,t){this.trigger("log",{level:"warn",message:"adts skiping bytes "+e+" to "+t+" in frame "+i+" outside syncword"})}
this.push=function(n){var r,a,s,o,u,l=0
e||(i=0)
if("audio"===n.type){if(t&&t.length){s=t;(t=new Uint8Array(s.byteLength+n.data.byteLength)).set(s)
t.set(n.data,s.byteLength)}else t=n.data
for(var c;l+7<t.length;)if(255===t[l]&&240==(246&t[l+1])){if("number"==typeof c){this.skipWarn_(c,l)
c=null}a=2*(1&~t[l+1])
r=(3&t[l+3])<<11|t[l+4]<<3|(224&t[l+5])>>5
u=(o=1024*(1+(3&t[l+6])))*ot/ut[(60&t[l+2])>>>2]
if(t.byteLength-l<r)break
this.trigger("data",{pts:n.pts+i*u,dts:n.dts+i*u,sampleCount:o,audioobjecttype:1+(t[l+2]>>>6&3),channelcount:(1&t[l+2])<<2|(192&t[l+3])>>>6,samplerate:ut[(60&t[l+2])>>>2],samplingfrequencyindex:(60&t[l+2])>>>2,samplesize:16,data:t.subarray(l+7+a,l+r)})
i++
l+=r}else{"number"!=typeof c&&(c=l)
l++}if("number"==typeof c){this.skipWarn_(c,l)
c=null}t=t.subarray(l)}}
this.flush=function(){i=0
this.trigger("done")}
this.reset=function(){t=void 0
this.trigger("reset")}
this.endTimeline=function(){t=void 0
this.trigger("endedtimeline")}}
at.prototype=new U
var lt,ct=at
lt=function(e){var t=e.byteLength,i=0,n=0
this.length=function(){return 8*t}
this.bitsAvailable=function(){return 8*t+n}
this.loadWord=function(){var r=e.byteLength-t,a=new Uint8Array(4),s=Math.min(4,t)
if(0===s)throw new Error("no bytes available")
a.set(e.subarray(r,r+s))
i=new DataView(a.buffer).getUint32(0)
n=8*s
t-=s}
this.skipBits=function(e){var r
if(n>e){i<<=e
n-=e}else{e-=n
e-=8*(r=Math.floor(e/8))
t-=r
this.loadWord()
i<<=e
n-=e}}
this.readBits=function(e){var r=Math.min(n,e),a=i>>>32-r;(n-=r)>0?i<<=r:t>0&&this.loadWord()
return(r=e-r)>0?a<<r|this.readBits(r):a}
this.skipLeadingZeros=function(){var e
for(e=0;e<n;++e)if(0!=(i&2147483648>>>e)){i<<=e
n-=e
return e}this.loadWord()
return e+this.skipLeadingZeros()}
this.skipUnsignedExpGolomb=function(){this.skipBits(1+this.skipLeadingZeros())}
this.skipExpGolomb=function(){this.skipBits(1+this.skipLeadingZeros())}
this.readUnsignedExpGolomb=function(){var e=this.skipLeadingZeros()
return this.readBits(e+1)-1}
this.readExpGolomb=function(){var e=this.readUnsignedExpGolomb()
return 1&e?1+e>>>1:-1*(e>>>1)}
this.readBoolean=function(){return 1===this.readBits(1)}
this.readUnsignedByte=function(){return this.readBits(8)}
this.loadWord()}
var dt,ht,pt,ft=lt
ht=function(){var e,t,i=0
ht.prototype.init.call(this)
this.push=function(n){var r
if(t){(r=new Uint8Array(t.byteLength+n.data.byteLength)).set(t)
r.set(n.data,t.byteLength)
t=r}else t=n.data
for(var a=t.byteLength;i<a-3;i++)if(1===t[i+2]){e=i+5
break}for(;e<a;)switch(t[e]){case 0:if(0!==t[e-1]){e+=2
break}if(0!==t[e-2]){e++
break}i+3!==e-2&&this.trigger("data",t.subarray(i+3,e-2))
do{e++}while(1!==t[e]&&e<a)
i=e-2
e+=3
break
case 1:if(0!==t[e-1]||0!==t[e-2]){e+=3
break}this.trigger("data",t.subarray(i+3,e-2))
i=e-2
e+=3
break
default:e+=3}t=t.subarray(i)
e-=i
i=0}
this.reset=function(){t=null
i=0
this.trigger("reset")}
this.flush=function(){t&&t.byteLength>3&&this.trigger("data",t.subarray(i+3))
t=null
i=0
this.trigger("done")}
this.endTimeline=function(){this.flush()
this.trigger("endedtimeline")}}
ht.prototype=new U
pt={100:!0,110:!0,122:!0,244:!0,44:!0,83:!0,86:!0,118:!0,128:!0,138:!0,139:!0,134:!0}
dt=function(){var e,t,i,n,r,a,s,o=new ht
dt.prototype.init.call(this)
e=this
this.push=function(e){if("video"===e.type){t=e.trackId
i=e.pts
n=e.dts
o.push(e)}}
o.on("data",(function(s){var o={trackId:t,pts:i,dts:n,data:s,nalUnitTypeCode:31&s[0]}
switch(o.nalUnitTypeCode){case 5:o.nalUnitType="slice_layer_without_partitioning_rbsp_idr"
break
case 6:o.nalUnitType="sei_rbsp"
o.escapedRBSP=r(s.subarray(1))
break
case 7:o.nalUnitType="seq_parameter_set_rbsp"
o.escapedRBSP=r(s.subarray(1))
o.config=a(o.escapedRBSP)
break
case 8:o.nalUnitType="pic_parameter_set_rbsp"
break
case 9:o.nalUnitType="access_unit_delimiter_rbsp"}e.trigger("data",o)}))
o.on("done",(function(){e.trigger("done")}))
o.on("partialdone",(function(){e.trigger("partialdone")}))
o.on("reset",(function(){e.trigger("reset")}))
o.on("endedtimeline",(function(){e.trigger("endedtimeline")}))
this.flush=function(){o.flush()}
this.partialFlush=function(){o.partialFlush()}
this.reset=function(){o.reset()}
this.endTimeline=function(){o.endTimeline()}
s=function(e,t){var i,n=8,r=8
for(i=0;i<e;i++){0!==r&&(r=(n+t.readExpGolomb()+256)%256)
n=0===r?n:r}}
r=function(e){for(var t,i,n=e.byteLength,r=[],a=1;a<n-2;)if(0===e[a]&&0===e[a+1]&&3===e[a+2]){r.push(a+2)
a+=2}else a++
if(0===r.length)return e
t=n-r.length
i=new Uint8Array(t)
var s=0
for(a=0;a<t;s++,a++){if(s===r[0]){s++
r.shift()}i[a]=e[s]}return i}
a=function(e){var t,i,n,r,a,o,u,l,c,d,h,p,f=0,m=0,g=0,v=0,y=[1,1]
i=(t=new ft(e)).readUnsignedByte()
r=t.readUnsignedByte()
n=t.readUnsignedByte()
t.skipUnsignedExpGolomb()
if(pt[i]){3===(a=t.readUnsignedExpGolomb())&&t.skipBits(1)
t.skipUnsignedExpGolomb()
t.skipUnsignedExpGolomb()
t.skipBits(1)
if(t.readBoolean()){h=3!==a?8:12
for(p=0;p<h;p++)t.readBoolean()&&s(p<6?16:64,t)}}t.skipUnsignedExpGolomb()
if(0===(o=t.readUnsignedExpGolomb()))t.readUnsignedExpGolomb()
else if(1===o){t.skipBits(1)
t.skipExpGolomb()
t.skipExpGolomb()
u=t.readUnsignedExpGolomb()
for(p=0;p<u;p++)t.skipExpGolomb()}t.skipUnsignedExpGolomb()
t.skipBits(1)
l=t.readUnsignedExpGolomb()
c=t.readUnsignedExpGolomb()
0===(d=t.readBits(1))&&t.skipBits(1)
t.skipBits(1)
if(t.readBoolean()){f=t.readUnsignedExpGolomb()
m=t.readUnsignedExpGolomb()
g=t.readUnsignedExpGolomb()
v=t.readUnsignedExpGolomb()}if(t.readBoolean()&&t.readBoolean()){switch(t.readUnsignedByte()){case 1:y=[1,1]
break
case 2:y=[12,11]
break
case 3:y=[10,11]
break
case 4:y=[16,11]
break
case 5:y=[40,33]
break
case 6:y=[24,11]
break
case 7:y=[20,11]
break
case 8:y=[32,11]
break
case 9:y=[80,33]
break
case 10:y=[18,11]
break
case 11:y=[15,11]
break
case 12:y=[64,33]
break
case 13:y=[160,99]
break
case 14:y=[4,3]
break
case 15:y=[3,2]
break
case 16:y=[2,1]
break
case 255:y=[t.readUnsignedByte()<<8|t.readUnsignedByte(),t.readUnsignedByte()<<8|t.readUnsignedByte()]}y&&(y[0],y[1])}return{profileIdc:i,levelIdc:n,profileCompatibility:r,width:16*(l+1)-2*f-2*m,height:(2-d)*(c+1)*16-2*g-2*v,sarRatio:y}}}
dt.prototype=new U
var mt,gt={H264Stream:dt,NalByteStream:ht},vt=[96e3,88200,64e3,48e3,44100,32e3,24e3,22050,16e3,12e3,11025,8e3,7350],yt=function(e,t){var i=e[t+6]<<21|e[t+7]<<14|e[t+8]<<7|e[t+9]
i=i>=0?i:0
return(16&e[t+5])>>4?i+20:i+10},_t=function e(t,i){return t.length-i<10||t[i]!=="I".charCodeAt(0)||t[i+1]!=="D".charCodeAt(0)||t[i+2]!=="3".charCodeAt(0)?i:e(t,i+=yt(t,i))},bt=function(e){return e[0]<<21|e[1]<<14|e[2]<<7|e[3]},Tt={isLikelyAacData:function(e){var t=_t(e,0)
return e.length>=t+2&&255==(255&e[t])&&240==(240&e[t+1])&&16==(22&e[t+1])},parseId3TagSize:yt,parseAdtsSize:function(e,t){var i=(224&e[t+5])>>5,n=e[t+4]<<3
return 6144&e[t+3]|n|i},parseType:function(e,t){return e[t]==="I".charCodeAt(0)&&e[t+1]==="D".charCodeAt(0)&&e[t+2]==="3".charCodeAt(0)?"timed-metadata":!0&e[t]&&240==(240&e[t+1])?"audio":null},parseSampleRate:function(e){for(var t=0;t+5<e.length;){if(255===e[t]&&240==(246&e[t+1]))return vt[(60&e[t+2])>>>2]
t++}return null},parseAacTimestamp:function(e){var t,i,n
t=10
if(64&e[5]){t+=4
t+=bt(e.subarray(10,14))}do{if((i=bt(e.subarray(t+4,t+8)))<1)return null
if("PRIV"===String.fromCharCode(e[t],e[t+1],e[t+2],e[t+3])){n=e.subarray(t+10,t+i+10)
for(var r=0;r<n.byteLength;r++)if(0===n[r]){var a=unescape(function(e,t,i){var n,r=""
for(n=t;n<i;n++)r+="%"+("00"+e[n].toString(16)).slice(-2)
return r}(n,0,r))
if("com.apple.streaming.transportStreamTimestamp"===a){var s=n.subarray(r+1),o=(1&s[3])<<30|s[4]<<22|s[5]<<14|s[6]<<6|s[7]>>>2
o*=4
return o+=3&s[7]}break}}t+=10
t+=i}while(t<e.byteLength)
return null}};(mt=function(){var e=new Uint8Array,t=0
mt.prototype.init.call(this)
this.setTimestamp=function(e){t=e}
this.push=function(i){var n,r,a,s,o=0,u=0
if(e.length){s=e.length;(e=new Uint8Array(i.byteLength+s)).set(e.subarray(0,s))
e.set(i,s)}else e=i
for(;e.length-u>=3;)if(e[u]!=="I".charCodeAt(0)||e[u+1]!=="D".charCodeAt(0)||e[u+2]!=="3".charCodeAt(0))if(255!=(255&e[u])||240!=(240&e[u+1]))u++
else{if(e.length-u<7)break
if(u+(o=Tt.parseAdtsSize(e,u))>e.length)break
a={type:"audio",data:e.subarray(u,u+o),pts:t,dts:t}
this.trigger("data",a)
u+=o}else{if(e.length-u<10)break
if(u+(o=Tt.parseId3TagSize(e,u))>e.length)break
r={type:"timed-metadata",data:e.subarray(u,u+o)}
this.trigger("data",r)
u+=o}n=e.length-u
e=n>0?e.subarray(u):new Uint8Array}
this.reset=function(){e=new Uint8Array
this.trigger("reset")}
this.endTimeline=function(){e=new Uint8Array
this.trigger("endedtimeline")}}).prototype=new U
var kt,St,Et,Ct,wt=mt,It=["audioobjecttype","channelcount","samplerate","samplingfrequencyindex","samplesize"],Pt=["width","height","profileIdc","levelIdc","profileCompatibility","sarRatio"],xt=gt.H264Stream,At=Tt.isLikelyAacData,Ot=le,Lt=function(e,t){t.stream=e
this.trigger("log",t)},Dt=function(e,t){for(var i=Object.keys(t),n=0;n<i.length;n++){var r=i[n]
"headOfPipeline"!==r&&t[r].on&&t[r].on("log",Lt.bind(e,r))}},Rt=function(e,t){var i
if(e.length!==t.length)return!1
for(i=0;i<e.length;i++)if(e[i]!==t[i])return!1
return!0},Mt=function(e,t,i,n,r,a){return{start:{dts:e,pts:e+(i-t)},end:{dts:e+(n-t),pts:e+(r-i)},prependedContentDuration:a,baseMediaDecodeTime:e}}
St=function(e,t){var i,n=[],r=0,a=0,s=1/0
i=(t=t||{}).firstSequenceNumber||0
St.prototype.init.call(this)
this.push=function(t){ke(e,t)
e&&It.forEach((function(i){e[i]=t[i]}))
n.push(t)}
this.setEarliestDts=function(e){r=e}
this.setVideoBaseMediaDecodeTime=function(e){s=e}
this.setAudioAppendStart=function(e){a=e}
this.flush=function(){var o,u,l,c,d,h,p
if(0!==n.length){o=ge(n,e,r)
e.baseMediaDecodeTime=Te(e,t.keepOriginalTimestamps)
p=me(e,o,a,s)
e.samples=ve(o)
l=Y(ye(o))
n=[]
u=Q(i,[e])
c=new Uint8Array(u.byteLength+l.byteLength)
i++
c.set(u)
c.set(l,u.byteLength)
be(e)
d=Math.ceil(1024*Ot/e.samplerate)
if(o.length){h=o.length*d
this.trigger("segmentTimingInfo",Mt(he(e.baseMediaDecodeTime,e.samplerate),o[0].dts,o[0].pts,o[0].dts+h,o[0].pts+h,p||0))
this.trigger("timingInfo",{start:o[0].pts,end:o[0].pts+h})}this.trigger("data",{track:e,boxes:c})
this.trigger("done","AudioSegmentStream")}else this.trigger("done","AudioSegmentStream")}
this.reset=function(){be(e)
n=[]
this.trigger("reset")}}
St.prototype=new U
kt=function(e,t){var i,n,r,a=[],s=[]
i=(t=t||{}).firstSequenceNumber||0
kt.prototype.init.call(this)
delete e.minPTS
this.gopCache_=[]
this.push=function(t){ke(e,t)
if("seq_parameter_set_rbsp"===t.nalUnitType&&!n){n=t.config
e.sps=[t.data]
Pt.forEach((function(t){e[t]=n[t]}),this)}if("pic_parameter_set_rbsp"===t.nalUnitType&&!r){r=t.data
e.pps=[t.data]}a.push(t)}
this.flush=function(){for(var n,r,o,u,l,c,d,h,p=0;a.length&&"access_unit_delimiter_rbsp"!==a[0].nalUnitType;)a.shift()
if(0!==a.length){n=Z(a)
if(!(o=ee(n))[0][0].keyFrame)if(r=this.getGopForFusion_(a[0],e)){p=r.duration
o.unshift(r)
o.byteLength+=r.byteLength
o.nalCount+=r.nalCount
o.pts=r.pts
o.dts=r.dts
o.duration+=r.duration}else o=te(o)
if(s.length){var f
if(!(f=t.alignGopsAtEnd?this.alignGopsAtEnd_(o):this.alignGopsAtStart_(o))){this.gopCache_.unshift({gop:o.pop(),pps:e.pps,sps:e.sps})
this.gopCache_.length=Math.min(6,this.gopCache_.length)
a=[]
this.resetStream_()
this.trigger("done","VideoSegmentStream")
return}be(e)
o=f}ke(e,o)
e.samples=ie(o)
l=Y(ne(o))
e.baseMediaDecodeTime=Te(e,t.keepOriginalTimestamps)
this.trigger("processedGopsInfo",o.map((function(e){return{pts:e.pts,dts:e.dts,byteLength:e.byteLength}})))
d=o[0]
h=o[o.length-1]
this.trigger("segmentTimingInfo",Mt(e.baseMediaDecodeTime,d.dts,d.pts,h.dts+h.duration,h.pts+h.duration,p))
this.trigger("timingInfo",{start:o[0].pts,end:o[o.length-1].pts+o[o.length-1].duration})
this.gopCache_.unshift({gop:o.pop(),pps:e.pps,sps:e.sps})
this.gopCache_.length=Math.min(6,this.gopCache_.length)
a=[]
this.trigger("baseMediaDecodeTime",e.baseMediaDecodeTime)
this.trigger("timelineStartInfo",e.timelineStartInfo)
u=Q(i,[e])
c=new Uint8Array(u.byteLength+l.byteLength)
i++
c.set(u)
c.set(l,u.byteLength)
this.trigger("data",{track:e,boxes:c})
this.resetStream_()
this.trigger("done","VideoSegmentStream")}else{this.resetStream_()
this.trigger("done","VideoSegmentStream")}}
this.reset=function(){this.resetStream_()
a=[]
this.gopCache_.length=0
s.length=0
this.trigger("reset")}
this.resetStream_=function(){be(e)
n=void 0
r=void 0}
this.getGopForFusion_=function(t){var i,n,r,a,s,o=1/0
for(s=0;s<this.gopCache_.length;s++){r=(a=this.gopCache_[s]).gop
if(e.pps&&Rt(e.pps[0],a.pps[0])&&e.sps&&Rt(e.sps[0],a.sps[0])&&(!(r.dts<e.timelineStartInfo.dts)&&(i=t.dts-r.dts-r.duration)>=-1e4&&i<=45e3&&(!n||o>i))){n=a
o=i}}return n?n.gop:null}
this.alignGopsAtStart_=function(e){var t,i,n,r,a,o,u,l
a=e.byteLength
o=e.nalCount
u=e.duration
t=i=0
for(;t<s.length&&i<e.length;){n=s[t]
r=e[i]
if(n.pts===r.pts)break
if(r.pts>n.pts)t++
else{i++
a-=r.byteLength
o-=r.nalCount
u-=r.duration}}if(0===i)return e
if(i===e.length)return null;(l=e.slice(i)).byteLength=a
l.duration=u
l.nalCount=o
l.pts=l[0].pts
l.dts=l[0].dts
return l}
this.alignGopsAtEnd_=function(e){var t,i,n,r,a,o,u
t=s.length-1
i=e.length-1
a=null
o=!1
for(;t>=0&&i>=0;){n=s[t]
r=e[i]
if(n.pts===r.pts){o=!0
break}if(n.pts>r.pts)t--
else{t===s.length-1&&(a=i)
i--}}if(!o&&null===a)return null
if(0===(u=o?i:a))return e
var l=e.slice(u),c=l.reduce((function(e,t){e.byteLength+=t.byteLength
e.duration+=t.duration
e.nalCount+=t.nalCount
return e}),{byteLength:0,duration:0,nalCount:0})
l.byteLength=c.byteLength
l.duration=c.duration
l.nalCount=c.nalCount
l.pts=l[0].pts
l.dts=l[0].dts
return l}
this.alignGopsWith=function(e){s=e}}
kt.prototype=new U
Ct=function(e,t){this.numberOfTracks=0
this.metadataStream=t
void 0!==(e=e||{}).remux?this.remuxTracks=!!e.remux:this.remuxTracks=!0
"boolean"==typeof e.keepOriginalTimestamps?this.keepOriginalTimestamps=e.keepOriginalTimestamps:this.keepOriginalTimestamps=!1
this.pendingTracks=[]
this.videoTrack=null
this.pendingBoxes=[]
this.pendingCaptions=[]
this.pendingMetadata=[]
this.pendingBytes=0
this.emittedTracks=0
Ct.prototype.init.call(this)
this.push=function(e){if(e.text)return this.pendingCaptions.push(e)
if(e.frames)return this.pendingMetadata.push(e)
this.pendingTracks.push(e.track)
this.pendingBytes+=e.boxes.byteLength
if("video"===e.track.type){this.videoTrack=e.track
this.pendingBoxes.push(e.boxes)}if("audio"===e.track.type){this.audioTrack=e.track
this.pendingBoxes.unshift(e.boxes)}}}
Ct.prototype=new U
Ct.prototype.flush=function(e){var t,i,n,r,a=0,s={captions:[],captionStreams:{},metadata:[],info:{}},o=0
if(this.pendingTracks.length<this.numberOfTracks){if("VideoSegmentStream"!==e&&"AudioSegmentStream"!==e)return
if(this.remuxTracks)return
if(0===this.pendingTracks.length){this.emittedTracks++
if(this.emittedTracks>=this.numberOfTracks){this.trigger("done")
this.emittedTracks=0}return}}if(this.videoTrack){o=this.videoTrack.timelineStartInfo.pts
Pt.forEach((function(e){s.info[e]=this.videoTrack[e]}),this)}else if(this.audioTrack){o=this.audioTrack.timelineStartInfo.pts
It.forEach((function(e){s.info[e]=this.audioTrack[e]}),this)}if(this.videoTrack||this.audioTrack){1===this.pendingTracks.length?s.type=this.pendingTracks[0].type:s.type="combined"
this.emittedTracks+=this.pendingTracks.length
n=$(this.pendingTracks)
s.initSegment=new Uint8Array(n.byteLength)
s.initSegment.set(n)
s.data=new Uint8Array(this.pendingBytes)
for(r=0;r<this.pendingBoxes.length;r++){s.data.set(this.pendingBoxes[r],a)
a+=this.pendingBoxes[r].byteLength}for(r=0;r<this.pendingCaptions.length;r++){(t=this.pendingCaptions[r]).startTime=fe(t.startPts,o,this.keepOriginalTimestamps)
t.endTime=fe(t.endPts,o,this.keepOriginalTimestamps)
s.captionStreams[t.stream]=!0
s.captions.push(t)}for(r=0;r<this.pendingMetadata.length;r++){(i=this.pendingMetadata[r]).cueTime=fe(i.pts,o,this.keepOriginalTimestamps)
s.metadata.push(i)}s.metadata.dispatchType=this.metadataStream.dispatchType
this.pendingTracks.length=0
this.videoTrack=null
this.pendingBoxes.length=0
this.pendingCaptions.length=0
this.pendingBytes=0
this.pendingMetadata.length=0
this.trigger("data",s)
for(r=0;r<s.captions.length;r++){t=s.captions[r]
this.trigger("caption",t)}for(r=0;r<s.metadata.length;r++){i=s.metadata[r]
this.trigger("id3Frame",i)}}if(this.emittedTracks>=this.numberOfTracks){this.trigger("done")
this.emittedTracks=0}}
Ct.prototype.setRemux=function(e){this.remuxTracks=e}
Et=function(e){var t,i,n=this,r=!0
Et.prototype.init.call(this)
e=e||{}
this.baseMediaDecodeTime=e.baseMediaDecodeTime||0
this.transmuxPipeline_={}
this.setupAacPipeline=function(){var r={}
this.transmuxPipeline_=r
r.type="aac"
r.metadataStream=new st.MetadataStream
r.aacStream=new wt
r.audioTimestampRolloverStream=new st.TimestampRolloverStream("audio")
r.timedMetadataTimestampRolloverStream=new st.TimestampRolloverStream("timed-metadata")
r.adtsStream=new ct
r.coalesceStream=new Ct(e,r.metadataStream)
r.headOfPipeline=r.aacStream
r.aacStream.pipe(r.audioTimestampRolloverStream).pipe(r.adtsStream)
r.aacStream.pipe(r.timedMetadataTimestampRolloverStream).pipe(r.metadataStream).pipe(r.coalesceStream)
r.metadataStream.on("timestamp",(function(e){r.aacStream.setTimestamp(e.timeStamp)}))
r.aacStream.on("data",(function(a){if(!("timed-metadata"!==a.type&&"audio"!==a.type||r.audioSegmentStream)){i=i||{timelineStartInfo:{baseMediaDecodeTime:n.baseMediaDecodeTime},codec:"adts",type:"audio"}
r.coalesceStream.numberOfTracks++
r.audioSegmentStream=new St(i,e)
r.audioSegmentStream.on("log",n.getLogTrigger_("audioSegmentStream"))
r.audioSegmentStream.on("timingInfo",n.trigger.bind(n,"audioTimingInfo"))
r.adtsStream.pipe(r.audioSegmentStream).pipe(r.coalesceStream)
n.trigger("trackinfo",{hasAudio:!!i,hasVideo:!!t})}}))
r.coalesceStream.on("data",this.trigger.bind(this,"data"))
r.coalesceStream.on("done",this.trigger.bind(this,"done"))
Dt(this,r)}
this.setupTsPipeline=function(){var r={}
this.transmuxPipeline_=r
r.type="ts"
r.metadataStream=new st.MetadataStream
r.packetStream=new st.TransportPacketStream
r.parseStream=new st.TransportParseStream
r.elementaryStream=new st.ElementaryStream
r.timestampRolloverStream=new st.TimestampRolloverStream
r.adtsStream=new ct
r.h264Stream=new xt
r.captionStream=new st.CaptionStream(e)
r.coalesceStream=new Ct(e,r.metadataStream)
r.headOfPipeline=r.packetStream
r.packetStream.pipe(r.parseStream).pipe(r.elementaryStream).pipe(r.timestampRolloverStream)
r.timestampRolloverStream.pipe(r.h264Stream)
r.timestampRolloverStream.pipe(r.adtsStream)
r.timestampRolloverStream.pipe(r.metadataStream).pipe(r.coalesceStream)
r.h264Stream.pipe(r.captionStream).pipe(r.coalesceStream)
r.elementaryStream.on("data",(function(a){var s
if("metadata"===a.type){s=a.tracks.length
for(;s--;)t||"video"!==a.tracks[s].type?i||"audio"!==a.tracks[s].type||((i=a.tracks[s]).timelineStartInfo.baseMediaDecodeTime=n.baseMediaDecodeTime):(t=a.tracks[s]).timelineStartInfo.baseMediaDecodeTime=n.baseMediaDecodeTime
if(t&&!r.videoSegmentStream){r.coalesceStream.numberOfTracks++
r.videoSegmentStream=new kt(t,e)
r.videoSegmentStream.on("log",n.getLogTrigger_("videoSegmentStream"))
r.videoSegmentStream.on("timelineStartInfo",(function(t){if(i&&!e.keepOriginalTimestamps){i.timelineStartInfo=t
r.audioSegmentStream.setEarliestDts(t.dts-n.baseMediaDecodeTime)}}))
r.videoSegmentStream.on("processedGopsInfo",n.trigger.bind(n,"gopInfo"))
r.videoSegmentStream.on("segmentTimingInfo",n.trigger.bind(n,"videoSegmentTimingInfo"))
r.videoSegmentStream.on("baseMediaDecodeTime",(function(e){i&&r.audioSegmentStream.setVideoBaseMediaDecodeTime(e)}))
r.videoSegmentStream.on("timingInfo",n.trigger.bind(n,"videoTimingInfo"))
r.h264Stream.pipe(r.videoSegmentStream).pipe(r.coalesceStream)}if(i&&!r.audioSegmentStream){r.coalesceStream.numberOfTracks++
r.audioSegmentStream=new St(i,e)
r.audioSegmentStream.on("log",n.getLogTrigger_("audioSegmentStream"))
r.audioSegmentStream.on("timingInfo",n.trigger.bind(n,"audioTimingInfo"))
r.audioSegmentStream.on("segmentTimingInfo",n.trigger.bind(n,"audioSegmentTimingInfo"))
r.adtsStream.pipe(r.audioSegmentStream).pipe(r.coalesceStream)}n.trigger("trackinfo",{hasAudio:!!i,hasVideo:!!t})}}))
r.coalesceStream.on("data",this.trigger.bind(this,"data"))
r.coalesceStream.on("id3Frame",(function(e){e.dispatchType=r.metadataStream.dispatchType
n.trigger("id3Frame",e)}))
r.coalesceStream.on("caption",this.trigger.bind(this,"caption"))
r.coalesceStream.on("done",this.trigger.bind(this,"done"))
Dt(this,r)}
this.setBaseMediaDecodeTime=function(n){var r=this.transmuxPipeline_
e.keepOriginalTimestamps||(this.baseMediaDecodeTime=n)
if(i){i.timelineStartInfo.dts=void 0
i.timelineStartInfo.pts=void 0
be(i)
r.audioTimestampRolloverStream&&r.audioTimestampRolloverStream.discontinuity()}if(t){r.videoSegmentStream&&(r.videoSegmentStream.gopCache_=[])
t.timelineStartInfo.dts=void 0
t.timelineStartInfo.pts=void 0
be(t)
r.captionStream.reset()}r.timestampRolloverStream&&r.timestampRolloverStream.discontinuity()}
this.setAudioAppendStart=function(e){i&&this.transmuxPipeline_.audioSegmentStream.setAudioAppendStart(e)}
this.setRemux=function(t){var i=this.transmuxPipeline_
e.remux=t
i&&i.coalesceStream&&i.coalesceStream.setRemux(t)}
this.alignGopsWith=function(e){t&&this.transmuxPipeline_.videoSegmentStream&&this.transmuxPipeline_.videoSegmentStream.alignGopsWith(e)}
this.getLogTrigger_=function(e){var t=this
return function(i){i.stream=e
t.trigger("log",i)}}
this.push=function(e){if(r){var t=At(e)
t&&"aac"!==this.transmuxPipeline_.type?this.setupAacPipeline():t||"ts"===this.transmuxPipeline_.type||this.setupTsPipeline()
r=!1}this.transmuxPipeline_.headOfPipeline.push(e)}
this.flush=function(){r=!0
this.transmuxPipeline_.headOfPipeline.flush()}
this.endTimeline=function(){this.transmuxPipeline_.headOfPipeline.endTimeline()}
this.reset=function(){this.transmuxPipeline_.headOfPipeline&&this.transmuxPipeline_.headOfPipeline.reset()}
this.resetCaptions=function(){this.transmuxPipeline_.captionStream&&this.transmuxPipeline_.captionStream.reset()}}
Et.prototype=new U
var Nt,Ut,Bt,Ft={Transmuxer:Et,VideoSegmentStream:kt,AudioSegmentStream:St,AUDIO_PROPERTIES:It,VIDEO_PROPERTIES:Pt,generateSegmentTimingInfo:Mt},jt=function(e){return e>>>0},Vt=function(e){var t=""
t+=String.fromCharCode(e[0])
t+=String.fromCharCode(e[1])
t+=String.fromCharCode(e[2])
return t+=String.fromCharCode(e[3])},Ht=jt,qt=function e(t,i){var n,r,a,s,o,u=[]
if(!i.length)return null
for(n=0;n<t.byteLength;){r=Ht(t[n]<<24|t[n+1]<<16|t[n+2]<<8|t[n+3])
a=Vt(t.subarray(n+4,n+8))
s=r>1?n+r:t.byteLength
a===i[0]&&(1===i.length?u.push(t.subarray(n+8,s)):(o=e(t.subarray(n+8,s),i.slice(1))).length&&(u=u.concat(o)))
n=s}return u},Wt=jt,Gt=F.getUint64,zt=function(e){var t={version:e[0],flags:new Uint8Array(e.subarray(1,4))}
1===t.version?t.baseMediaDecodeTime=Gt(e.subarray(4)):t.baseMediaDecodeTime=Wt(e[4]<<24|e[5]<<16|e[6]<<8|e[7])
return t},Xt=function(e){return{isLeading:(12&e[0])>>>2,dependsOn:3&e[0],isDependedOn:(192&e[1])>>>6,hasRedundancy:(48&e[1])>>>4,paddingValue:(14&e[1])>>>1,isNonSyncSample:1&e[1],degradationPriority:e[2]<<8|e[3]}},Kt=function(e){var t,i={version:e[0],flags:new Uint8Array(e.subarray(1,4)),samples:[]},n=new DataView(e.buffer,e.byteOffset,e.byteLength),r=1&i.flags[2],a=4&i.flags[2],s=1&i.flags[1],o=2&i.flags[1],u=4&i.flags[1],l=8&i.flags[1],c=n.getUint32(4),d=8
if(r){i.dataOffset=n.getInt32(d)
d+=4}if(a&&c){t={flags:Xt(e.subarray(d,d+4))}
d+=4
if(s){t.duration=n.getUint32(d)
d+=4}if(o){t.size=n.getUint32(d)
d+=4}if(l){1===i.version?t.compositionTimeOffset=n.getInt32(d):t.compositionTimeOffset=n.getUint32(d)
d+=4}i.samples.push(t)
c--}for(;c--;){t={}
if(s){t.duration=n.getUint32(d)
d+=4}if(o){t.size=n.getUint32(d)
d+=4}if(u){t.flags=Xt(e.subarray(d,d+4))
d+=4}if(l){1===i.version?t.compositionTimeOffset=n.getInt32(d):t.compositionTimeOffset=n.getUint32(d)
d+=4}i.samples.push(t)}return i},Yt=function(e){var t,i=new DataView(e.buffer,e.byteOffset,e.byteLength),n={version:e[0],flags:new Uint8Array(e.subarray(1,4)),trackId:i.getUint32(4)},r=1&n.flags[2],a=2&n.flags[2],s=8&n.flags[2],o=16&n.flags[2],u=32&n.flags[2],l=65536&n.flags[0],c=131072&n.flags[0]
t=8
if(r){t+=4
n.baseDataOffset=i.getUint32(12)
t+=4}if(a){n.sampleDescriptionIndex=i.getUint32(t)
t+=4}if(s){n.defaultSampleDuration=i.getUint32(t)
t+=4}if(o){n.defaultSampleSize=i.getUint32(t)
t+=4}u&&(n.defaultSampleFlags=i.getUint32(t))
l&&(n.durationIsEmpty=!0)
!r&&c&&(n.baseDataOffsetIsMoof=!0)
return n},Qt="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},$t="undefined"!=typeof window?window:void 0!==Qt?Qt:"undefined"!=typeof self?self:{},Jt=we,Zt=Fe.CaptionStream,ei=function(e,t){for(var i=e,n=0;n<t.length;n++){var r=t[n]
if(i<r.size)return r
i-=r.size}return null},ti=function(e,t){var i=qt(e,["moof","traf"]),n=qt(e,["mdat"]),r={},a=[]
n.forEach((function(e,t){var n=i[t]
a.push({mdat:e,traf:n})}))
a.forEach((function(e){var i,n,a=e.mdat,s=e.traf,o=qt(s,["tfhd"]),u=Yt(o[0]),l=u.trackId,c=qt(s,["tfdt"]),d=c.length>0?zt(c[0]).baseMediaDecodeTime:0,h=qt(s,["trun"])
if(t===l&&h.length>0){i=function(e,t,i){var n=t,r=i.defaultSampleDuration||0,a=i.defaultSampleSize||0,s=i.trackId,o=[]
e.forEach((function(e){var t=Kt(e).samples
t.forEach((function(e){void 0===e.duration&&(e.duration=r)
void 0===e.size&&(e.size=a)
e.trackId=s
e.dts=n
void 0===e.compositionTimeOffset&&(e.compositionTimeOffset=0)
if("bigint"==typeof n){e.pts=n+$t.BigInt(e.compositionTimeOffset)
n+=$t.BigInt(e.duration)}else{e.pts=n+e.compositionTimeOffset
n+=e.duration}}))
o=o.concat(t)}))
return o}(h,d,u)
n=function(e,t,i){var n,r,a,s,o=new DataView(e.buffer,e.byteOffset,e.byteLength),u={logs:[],seiNals:[]}
for(r=0;r+4<e.length;r+=a){a=o.getUint32(r)
r+=4
if(!(a<=0))switch(31&e[r]){case 6:var l=e.subarray(r+1,r+1+a),c=ei(r,t)
n={nalUnitType:"sei_rbsp",size:a,data:l,escapedRBSP:Jt(l),trackId:i}
if(c){n.pts=c.pts
n.dts=c.dts
s=c}else{if(!s){u.logs.push({level:"warn",message:"We've encountered a nal unit without data at "+r+" for trackId "+i+". See mux.js#223."})
break}n.pts=s.pts
n.dts=s.dts}u.seiNals.push(n)}}return u}(a,i,l)
r[l]||(r[l]={seiNals:[],logs:[]})
r[l].seiNals=r[l].seiNals.concat(n.seiNals)
r[l].logs=r[l].logs.concat(n.logs)}}))
return r},ii=function(){var e,t,i,n,r,a,s=!1
this.isInitialized=function(){return s}
this.init=function(t){e=new Zt
s=!0
a=!!t&&t.isPartial
e.on("data",(function(e){e.startTime=e.startPts/n
e.endTime=e.endPts/n
r.captions.push(e)
r.captionStreams[e.stream]=!0}))
e.on("log",(function(e){r.logs.push(e)}))}
this.isNewInit=function(e,t){return!(e&&0===e.length||t&&"object"==typeof t&&0===Object.keys(t).length)&&(i!==e[0]||n!==t[i])}
this.parse=function(e,a,s){var o
if(!this.isInitialized())return null
if(!a||!s)return null
if(this.isNewInit(a,s)){i=a[0]
n=s[i]}else if(null===i||!n){t.push(e)
return null}for(;t.length>0;){var u=t.shift()
this.parse(u,a,s)}o=function(e,t,i){if(null===t)return null
var n=ti(e,t)[t]||{}
return{seiNals:n.seiNals,logs:n.logs,timescale:i}}(e,i,n)
o&&o.logs&&(r.logs=r.logs.concat(o.logs))
if(null===o||!o.seiNals)return r.logs.length?{logs:r.logs,captions:[],captionStreams:[]}:null
this.pushNals(o.seiNals)
this.flushStream()
return r}
this.pushNals=function(t){if(!this.isInitialized()||!t||0===t.length)return null
t.forEach((function(t){e.push(t)}))}
this.flushStream=function(){if(!this.isInitialized())return null
a?e.partialFlush():e.flush()}
this.clearParsedCaptions=function(){r.captions=[]
r.captionStreams={}
r.logs=[]}
this.resetCaptionStream=function(){if(!this.isInitialized())return null
e.reset()}
this.clearAllCaptions=function(){this.clearParsedCaptions()
this.resetCaptionStream()}
this.reset=function(){t=[]
i=null
n=null
r?this.clearParsedCaptions():r={captions:[],captionStreams:{},logs:[]}
this.resetCaptionStream()}
this.reset()},ni=jt,ri=function(e){return("00"+e.toString(16)).slice(-2)},ai=F.getUint64;(function(e){return qt(e,["moov","trak"]).reduce((function(e,t){var i,n,r,a,s
if(!(i=qt(t,["tkhd"])[0]))return null
n=i[0]
a=ni(i[r=0===n?12:20]<<24|i[r+1]<<16|i[r+2]<<8|i[r+3])
if(!(s=qt(t,["mdia","mdhd"])[0]))return null
r=0===(n=s[0])?12:20
e[a]=ni(s[r]<<24|s[r+1]<<16|s[r+2]<<8|s[r+3])
return e}),{})})
Nt=function(e,t){var i=qt(t,["moof","traf"]).reduce((function(t,i){var n,r,a=qt(i,["tfhd"])[0],s=ni(a[4]<<24|a[5]<<16|a[6]<<8|a[7]),o=e[s]||9e4,u=qt(i,["tfdt"])[0],l=new DataView(u.buffer,u.byteOffset,u.byteLength)
"bigint"==typeof(n=1===u[0]?ai(u.subarray(4,12)):l.getUint32(4))?r=n/$t.BigInt(o):"number"!=typeof n||isNaN(n)||(r=n/o)
r<Number.MAX_SAFE_INTEGER&&(r=Number(r))
r<t&&(t=r)
return t}),1/0)
return"bigint"==typeof i||isFinite(i)?i:0};(function(e,t){var i,n=qt(t,["moof","traf"]),r=0,a=0
if(n&&n.length){var s=qt(n[0],["tfhd"])[0],o=qt(n[0],["trun"])[0],u=qt(n[0],["tfdt"])[0]
if(s){i=Yt(s).trackId}if(u){r=zt(u).baseMediaDecodeTime}if(o){var l=Kt(o)
l.samples&&l.samples.length&&(a=l.samples[0].compositionTimeOffset||0)}}var c=e[i]||9e4
if("bigint"==typeof r){a=$t.BigInt(a)
c=$t.BigInt(c)}var d=(r+a)/c
"bigint"==typeof d&&d<Number.MAX_SAFE_INTEGER&&(d=Number(d))
return d});(function(e){var t=qt(e,["moov","trak"]),i=[]
t.forEach((function(e){var t=qt(e,["mdia","hdlr"]),n=qt(e,["tkhd"])
t.forEach((function(e,t){var r,a,s=Vt(e.subarray(8,12)),o=n[t]
if("vide"===s){a=0===(r=new DataView(o.buffer,o.byteOffset,o.byteLength)).getUint8(0)?r.getUint32(12):r.getUint32(20)
i.push(a)}}))}))
return i})
Bt=function(e){var t=0===e[0]?12:20
return ni(e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3])}
Ut=function(e){var t=qt(e,["moov","trak"]),i=[]
t.forEach((function(e){var t,n,r={},a=qt(e,["tkhd"])[0]
if(a){n=(t=new DataView(a.buffer,a.byteOffset,a.byteLength)).getUint8(0)
r.id=0===n?t.getUint32(12):t.getUint32(20)}var s=qt(e,["mdia","hdlr"])[0]
if(s){var o=Vt(s.subarray(8,12))
r.type="vide"===o?"video":"soun"===o?"audio":o}var u=qt(e,["mdia","minf","stbl","stsd"])[0]
if(u){var l=u.subarray(8)
r.codec=Vt(l.subarray(4,8))
var c,d=qt(l,[r.codec])[0]
if(d)if(/^[asm]vc[1-9]$/i.test(r.codec)){c=d.subarray(78)
if("avcC"===Vt(c.subarray(4,8))&&c.length>11){r.codec+="."
r.codec+=ri(c[9])
r.codec+=ri(c[10])
r.codec+=ri(c[11])}else r.codec="avc1.4d400d"}else if(/^mp4[a,v]$/i.test(r.codec)){c=d.subarray(28)
if("esds"===Vt(c.subarray(4,8))&&c.length>20&&0!==c[19]){r.codec+="."+ri(c[19])
r.codec+="."+ri(c[20]>>>2&63).replace(/^0/,"")}else r.codec="mp4a.40.2"}else r.codec=r.codec.toLowerCase()}var h=qt(e,["mdia","mdhd"])[0]
h&&(r.timescale=Bt(h))
i.push(r)}))
return i}
var si=Nt,oi=Ut,ui=function(e){var t=31&e[1]
t<<=8
return t|=e[2]},li=function(e){return!!(64&e[1])},ci=function(e){var t=0;(48&e[3])>>>4>1&&(t+=e[4]+1)
return t},di=function(e){switch(e){case 5:return"slice_layer_without_partitioning_rbsp_idr"
case 6:return"sei_rbsp"
case 7:return"seq_parameter_set_rbsp"
case 8:return"pic_parameter_set_rbsp"
case 9:return"access_unit_delimiter_rbsp"
default:return null}},hi={parseType:function(e,t){var i=ui(e)
return 0===i?"pat":i===t?"pmt":t?"pes":null},parsePat:function(e){var t=li(e),i=4+ci(e)
t&&(i+=e[i]+1)
return(31&e[i+10])<<8|e[i+11]},parsePmt:function(e){var t={},i=li(e),n=4+ci(e)
i&&(n+=e[n]+1)
if(1&e[n+5]){var r
r=3+((15&e[n+1])<<8|e[n+2])-4
for(var a=12+((15&e[n+10])<<8|e[n+11]);a<r;){var s=n+a
t[(31&e[s+1])<<8|e[s+2]]=e[s]
a+=5+((15&e[s+3])<<8|e[s+4])}return t}},parsePayloadUnitStartIndicator:li,parsePesType:function(e,t){switch(t[ui(e)]){case je.H264_STREAM_TYPE:return"video"
case je.ADTS_STREAM_TYPE:return"audio"
case je.METADATA_STREAM_TYPE:return"timed-metadata"
default:return null}},parsePesTime:function(e){if(!li(e))return null
var t=4+ci(e)
if(t>=e.byteLength)return null
var i,n=null
if(192&(i=e[t+7])){(n={}).pts=(14&e[t+9])<<27|(255&e[t+10])<<20|(254&e[t+11])<<12|(255&e[t+12])<<5|(254&e[t+13])>>>3
n.pts*=4
n.pts+=(6&e[t+13])>>>1
n.dts=n.pts
if(64&i){n.dts=(14&e[t+14])<<27|(255&e[t+15])<<20|(254&e[t+16])<<12|(255&e[t+17])<<5|(254&e[t+18])>>>3
n.dts*=4
n.dts+=(6&e[t+18])>>>1}}return n},videoPacketContainsKeyFrame:function(e){for(var t=4+ci(e),i=e.subarray(t),n=0,r=0,a=!1;r<i.byteLength-3;r++)if(1===i[r+2]){n=r+5
break}for(;n<i.byteLength;)switch(i[n]){case 0:if(0!==i[n-1]){n+=2
break}if(0!==i[n-2]){n++
break}r+3!==n-2&&"slice_layer_without_partitioning_rbsp_idr"===di(31&i[r+3])&&(a=!0)
do{n++}while(1!==i[n]&&n<i.length)
r=n-2
n+=3
break
case 1:if(0!==i[n-1]||0!==i[n-2]){n+=3
break}"slice_layer_without_partitioning_rbsp_idr"===di(31&i[r+3])&&(a=!0)
r=n-2
n+=3
break
default:n+=3}i=i.subarray(r)
n-=r
r=0
i&&i.byteLength>3&&"slice_layer_without_partitioning_rbsp_idr"===di(31&i[r+3])&&(a=!0)
return a}},pi=ze,fi={}
fi.ts=hi
fi.aac=Tt
var mi=le,gi=188,vi=71,yi=function(e,t,i){for(var n,r,a,s,o=0,u=gi,l=!1;u<=e.byteLength;)if(e[o]!==vi||e[u]!==vi&&u!==e.byteLength){o++
u++}else{n=e.subarray(o,u)
if("pes"===fi.ts.parseType(n,t.pid)){r=fi.ts.parsePesType(n,t.table)
a=fi.ts.parsePayloadUnitStartIndicator(n)
if("audio"===r&&a&&(s=fi.ts.parsePesTime(n))){s.type="audio"
i.audio.push(s)
l=!0}}if(l)break
o+=gi
u+=gi}o=(u=e.byteLength)-gi
l=!1
for(;o>=0;)if(e[o]!==vi||e[u]!==vi&&u!==e.byteLength){o--
u--}else{n=e.subarray(o,u)
if("pes"===fi.ts.parseType(n,t.pid)){r=fi.ts.parsePesType(n,t.table)
a=fi.ts.parsePayloadUnitStartIndicator(n)
if("audio"===r&&a&&(s=fi.ts.parsePesTime(n))){s.type="audio"
i.audio.push(s)
l=!0}}if(l)break
o-=gi
u-=gi}},_i=function(e,t,i){for(var n,r,a,s,o,u,l,c=0,d=gi,h=!1,p={data:[],size:0};d<e.byteLength;)if(e[c]!==vi||e[d]!==vi){c++
d++}else{n=e.subarray(c,d)
if("pes"===fi.ts.parseType(n,t.pid)){r=fi.ts.parsePesType(n,t.table)
a=fi.ts.parsePayloadUnitStartIndicator(n)
if("video"===r){if(a&&!h&&(s=fi.ts.parsePesTime(n))){s.type="video"
i.video.push(s)
h=!0}if(!i.firstKeyFrame){if(a&&0!==p.size){o=new Uint8Array(p.size)
u=0
for(;p.data.length;){l=p.data.shift()
o.set(l,u)
u+=l.byteLength}if(fi.ts.videoPacketContainsKeyFrame(o)){var f=fi.ts.parsePesTime(o)
if(f){i.firstKeyFrame=f
i.firstKeyFrame.type="video"}else console.warn("Failed to extract PTS/DTS from PES at first keyframe. This could be an unusual TS segment, or else mux.js did not parse your TS segment correctly. If you know your TS segments do contain PTS/DTS on keyframes please file a bug report! You can try ffprobe to double check for yourself.")}p.size=0}p.data.push(n)
p.size+=n.byteLength}}}if(h&&i.firstKeyFrame)break
c+=gi
d+=gi}c=(d=e.byteLength)-gi
h=!1
for(;c>=0;)if(e[c]!==vi||e[d]!==vi){c--
d--}else{n=e.subarray(c,d)
if("pes"===fi.ts.parseType(n,t.pid)){r=fi.ts.parsePesType(n,t.table)
a=fi.ts.parsePayloadUnitStartIndicator(n)
if("video"===r&&a&&(s=fi.ts.parsePesTime(n))){s.type="video"
i.video.push(s)
h=!0}}if(h)break
c-=gi
d-=gi}},bi=function(e){var t={pid:null,table:null},i={}
!function(e,t){for(var i,n=0,r=gi;r<e.byteLength;)if(e[n]!==vi||e[r]!==vi){n++
r++}else{i=e.subarray(n,r)
switch(fi.ts.parseType(i,t.pid)){case"pat":t.pid=fi.ts.parsePat(i)
break
case"pmt":var a=fi.ts.parsePmt(i)
t.table=t.table||{}
Object.keys(a).forEach((function(e){t.table[e]=a[e]}))}n+=gi
r+=gi}}(e,t)
for(var n in t.table)if(t.table.hasOwnProperty(n)){switch(t.table[n]){case je.H264_STREAM_TYPE:i.video=[]
_i(e,t,i)
0===i.video.length&&delete i.video
break
case je.ADTS_STREAM_TYPE:i.audio=[]
yi(e,t,i)
0===i.audio.length&&delete i.audio}}return i},Ti=function(e,t){var i
i=fi.aac.isLikelyAacData(e)?function(e){for(var t,i=!1,n=0,r=null,a=null,s=0,o=0;e.length-o>=3;){switch(fi.aac.parseType(e,o)){case"timed-metadata":if(e.length-o<10){i=!0
break}if((s=fi.aac.parseId3TagSize(e,o))>e.length){i=!0
break}if(null===a){t=e.subarray(o,o+s)
a=fi.aac.parseAacTimestamp(t)}o+=s
break
case"audio":if(e.length-o<7){i=!0
break}if((s=fi.aac.parseAdtsSize(e,o))>e.length){i=!0
break}if(null===r){t=e.subarray(o,o+s)
r=fi.aac.parseSampleRate(t)}n++
o+=s
break
default:o++}if(i)return null}if(null===r||null===a)return null
var u=mi/r
return{audio:[{type:"audio",dts:a,pts:a},{type:"audio",dts:a+1024*n*u,pts:a+1024*n*u}]}}(e):bi(e)
if(!i||!i.audio&&!i.video)return null
!function(e,t){if(e.audio&&e.audio.length){var i=t;(void 0===i||isNaN(i))&&(i=e.audio[0].dts)
e.audio.forEach((function(e){e.dts=pi(e.dts,i)
e.pts=pi(e.pts,i)
e.dtsTime=e.dts/mi
e.ptsTime=e.pts/mi}))}if(e.video&&e.video.length){var n=t;(void 0===n||isNaN(n))&&(n=e.video[0].dts)
e.video.forEach((function(e){e.dts=pi(e.dts,n)
e.pts=pi(e.pts,n)
e.dtsTime=e.dts/mi
e.ptsTime=e.pts/mi}))
if(e.firstKeyFrame){var r=e.firstKeyFrame
r.dts=pi(r.dts,n)
r.pts=pi(r.pts,n)
r.dtsTime=r.dts/mi
r.ptsTime=r.pts/mi}}}(i,t)
return i},ki=function(){function e(e,t){this.options=t||{}
this.self=e
this.init()}var t=e.prototype
t.init=function(){this.transmuxer&&this.transmuxer.dispose()
this.transmuxer=new Ft.Transmuxer(this.options)
!function(e,t){t.on("data",(function(t){var i=t.initSegment
t.initSegment={data:i.buffer,byteOffset:i.byteOffset,byteLength:i.byteLength}
var n=t.data
t.data=n.buffer
e.postMessage({action:"data",segment:t,byteOffset:n.byteOffset,byteLength:n.byteLength},[t.data])}))
t.on("done",(function(t){e.postMessage({action:"done"})}))
t.on("gopInfo",(function(t){e.postMessage({action:"gopInfo",gopInfo:t})}))
t.on("videoSegmentTimingInfo",(function(t){var i={start:{decode:de(t.start.dts),presentation:de(t.start.pts)},end:{decode:de(t.end.dts),presentation:de(t.end.pts)},baseMediaDecodeTime:de(t.baseMediaDecodeTime)}
t.prependedContentDuration&&(i.prependedContentDuration=de(t.prependedContentDuration))
e.postMessage({action:"videoSegmentTimingInfo",videoSegmentTimingInfo:i})}))
t.on("audioSegmentTimingInfo",(function(t){var i={start:{decode:de(t.start.dts),presentation:de(t.start.pts)},end:{decode:de(t.end.dts),presentation:de(t.end.pts)},baseMediaDecodeTime:de(t.baseMediaDecodeTime)}
t.prependedContentDuration&&(i.prependedContentDuration=de(t.prependedContentDuration))
e.postMessage({action:"audioSegmentTimingInfo",audioSegmentTimingInfo:i})}))
t.on("id3Frame",(function(t){e.postMessage({action:"id3Frame",id3Frame:t})}))
t.on("caption",(function(t){e.postMessage({action:"caption",caption:t})}))
t.on("trackinfo",(function(t){e.postMessage({action:"trackinfo",trackInfo:t})}))
t.on("audioTimingInfo",(function(t){e.postMessage({action:"audioTimingInfo",audioTimingInfo:{start:de(t.start),end:de(t.end)}})}))
t.on("videoTimingInfo",(function(t){e.postMessage({action:"videoTimingInfo",videoTimingInfo:{start:de(t.start),end:de(t.end)}})}))
t.on("log",(function(t){e.postMessage({action:"log",log:t})}))}(this.self,this.transmuxer)}
t.pushMp4Captions=function(e){if(!this.captionParser){this.captionParser=new ii
this.captionParser.init()}var t=new Uint8Array(e.data,e.byteOffset,e.byteLength),i=this.captionParser.parse(t,e.trackIds,e.timescales)
this.self.postMessage({action:"mp4Captions",captions:i&&i.captions||[],logs:i&&i.logs||[],data:t.buffer},[t.buffer])}
t.probeMp4StartTime=function(e){var t=e.timescales,i=e.data,n=si(t,i)
this.self.postMessage({action:"probeMp4StartTime",startTime:n,data:i},[i.buffer])}
t.probeMp4Tracks=function(e){var t=e.data,i=oi(t)
this.self.postMessage({action:"probeMp4Tracks",tracks:i,data:t},[t.buffer])}
t.probeTs=function(e){var t=e.data,i=e.baseStartTime,n="number"!=typeof i||isNaN(i)?void 0:i*le,r=Ti(t,n),a=null
if(r){(a={hasVideo:r.video&&2===r.video.length||!1,hasAudio:r.audio&&2===r.audio.length||!1}).hasVideo&&(a.videoStart=r.video[0].ptsTime)
a.hasAudio&&(a.audioStart=r.audio[0].ptsTime)}this.self.postMessage({action:"probeTs",result:a,data:t},[t.buffer])}
t.clearAllMp4Captions=function(){this.captionParser&&this.captionParser.clearAllCaptions()}
t.clearParsedMp4Captions=function(){this.captionParser&&this.captionParser.clearParsedCaptions()}
t.push=function(e){var t=new Uint8Array(e.data,e.byteOffset,e.byteLength)
this.transmuxer.push(t)}
t.reset=function(){this.transmuxer.reset()}
t.setTimestampOffset=function(e){var t=e.timestampOffset||0
this.transmuxer.setBaseMediaDecodeTime(Math.round(ce(t)))}
t.setAudioAppendStart=function(e){this.transmuxer.setAudioAppendStart(Math.ceil(ce(e.appendStart)))}
t.setRemux=function(e){this.transmuxer.setRemux(e.remux)}
t.flush=function(e){this.transmuxer.flush()
self.postMessage({action:"done",type:"transmuxed"})}
t.endTimeline=function(){this.transmuxer.endTimeline()
self.postMessage({action:"endedtimeline",type:"transmuxed"})}
t.alignGopsWith=function(e){this.transmuxer.alignGopsWith(e.gopsToAlignWith.slice())}
return e}()
self.onmessage=function(e){if("init"===e.data.action&&e.data.options)this.messageHandlers=new ki(self,e.data.options)
else{this.messageHandlers||(this.messageHandlers=new ki(self))
e.data&&e.data.action&&"init"!==e.data.action&&this.messageHandlers[e.data.action]&&this.messageHandlers[e.data.action](e.data)}}