var browserWorkerPolyFill = function(e){e.on=e.addEventListener
e.off=e.removeEventListener
return e};
browserWorkerPolyFill(self);
function e(e,t,i){return e(i={path:t,exports:{},require:function(e,t){return function(){throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs")}(null==t&&i.path)}},i.exports),i.exports}var t=e((function(e){function t(e,t){for(var i=0;i<t.length;i++){var n=t[i]
n.enumerable=n.enumerable||!1
n.configurable=!0
"value"in n&&(n.writable=!0)
Object.defineProperty(e,n.key,n)}}e.exports=function(e,i,n){i&&t(e.prototype,i)
n&&t(e,n)
return e}
e.exports.default=e.exports,e.exports.__esModule=!0})),i=e((function(e){function t(i,n){e.exports=t=Object.setPrototypeOf||function(e,t){e.__proto__=t
return e}
e.exports.default=e.exports,e.exports.__esModule=!0
return t(i,n)}e.exports=t
e.exports.default=e.exports,e.exports.__esModule=!0})),n=e((function(e){e.exports=function(e,t){e.prototype=Object.create(t.prototype)
e.prototype.constructor=e
i(e,t)}
e.exports.default=e.exports,e.exports.__esModule=!0})),r=function(){function e(){this.listeners={}}var t=e.prototype
t.on=function(e,t){this.listeners[e]||(this.listeners[e]=[])
this.listeners[e].push(t)}
t.off=function(e,t){if(!this.listeners[e])return!1
var i=this.listeners[e].indexOf(t)
this.listeners[e]=this.listeners[e].slice(0)
this.listeners[e].splice(i,1)
return i>-1}
t.trigger=function(e){var t=this.listeners[e]
if(t)if(2===arguments.length)for(var i=t.length,n=0;n<i;++n)t[n].call(this,arguments[1])
else for(var r=Array.prototype.slice.call(arguments,1),a=t.length,s=0;s<a;++s)t[s].apply(this,r)}
t.dispose=function(){this.listeners={}}
t.pipe=function(e){this.on("data",(function(t){e.push(t)}))}
return e}()

;/*! @name aes-decrypter @version 3.1.2 @license Apache-2.0 */
var a=null,s=function(){function e(e){a||(a=function(){var e,t,i,n,r,a,s,o,u=[[[],[],[],[],[]],[[],[],[],[],[]]],l=u[0],c=u[1],d=l[4],h=c[4],p=[],f=[]
for(e=0;e<256;e++)f[(p[e]=e<<1^283*(e>>7))^e]=e
for(t=i=0;!d[t];t^=n||1,i=f[i]||1){a=(a=i^i<<1^i<<2^i<<3^i<<4)>>8^255&a^99
d[t]=a
h[a]=t
o=16843009*p[r=p[n=p[t]]]^65537*r^257*n^16843008*t
s=257*p[a]^16843008*a
for(e=0;e<4;e++){l[e][t]=s=s<<24^s>>>8
c[e][a]=o=o<<24^o>>>8}}for(e=0;e<5;e++){l[e]=l[e].slice(0)
c[e]=c[e].slice(0)}return u}())
this._tables=[[a[0][0].slice(),a[0][1].slice(),a[0][2].slice(),a[0][3].slice(),a[0][4].slice()],[a[1][0].slice(),a[1][1].slice(),a[1][2].slice(),a[1][3].slice(),a[1][4].slice()]]
var t,i,n,r=this._tables[0][4],s=this._tables[1],o=e.length,u=1
if(4!==o&&6!==o&&8!==o)throw new Error("Invalid aes key size")
var l=e.slice(0),c=[]
this._key=[l,c]
for(t=o;t<4*o+28;t++){n=l[t-1]
if(t%o==0||8===o&&t%o==4){n=r[n>>>24]<<24^r[n>>16&255]<<16^r[n>>8&255]<<8^r[255&n]
if(t%o==0){n=n<<8^n>>>24^u<<24
u=u<<1^283*(u>>7)}}l[t]=l[t-o]^n}for(i=0;t;i++,t--){n=l[3&i?t:t-4]
c[i]=t<=4||i<4?n:s[0][r[n>>>24]]^s[1][r[n>>16&255]]^s[2][r[n>>8&255]]^s[3][r[255&n]]}}e.prototype.decrypt=function(e,t,i,n,r,a){var s,o,u,l,c=this._key[1],d=e^c[0],h=n^c[1],p=i^c[2],f=t^c[3],m=c.length/4-2,g=4,v=this._tables[1],y=v[0],_=v[1],b=v[2],T=v[3],k=v[4]
for(l=0;l<m;l++){s=y[d>>>24]^_[h>>16&255]^b[p>>8&255]^T[255&f]^c[g]
o=y[h>>>24]^_[p>>16&255]^b[f>>8&255]^T[255&d]^c[g+1]
u=y[p>>>24]^_[f>>16&255]^b[d>>8&255]^T[255&h]^c[g+2]
f=y[f>>>24]^_[d>>16&255]^b[h>>8&255]^T[255&p]^c[g+3]
g+=4
d=s
h=o
p=u}for(l=0;l<4;l++){r[(3&-l)+a]=k[d>>>24]<<24^k[h>>16&255]<<16^k[p>>8&255]<<8^k[255&f]^c[g++]
s=d
d=h
h=p
p=f
f=s}}
return e}(),o=function(e){n(t,e)
function t(){var t;(t=e.call(this,r)||this).jobs=[]
t.delay=1
t.timeout_=null
return t}var i=t.prototype
i.processJob_=function(){this.jobs.shift()()
this.jobs.length?this.timeout_=setTimeout(this.processJob_.bind(this),this.delay):this.timeout_=null}
i.push=function(e){this.jobs.push(e)
this.timeout_||(this.timeout_=setTimeout(this.processJob_.bind(this),this.delay))}
return t}(r),u=function(e){return e<<24|(65280&e)<<8|(16711680&e)>>8|e>>>24},l=function(){function e(t,i,n,r){var a=e.STEP,s=new Int32Array(t.buffer),l=new Uint8Array(t.byteLength),c=0
this.asyncStream_=new o
this.asyncStream_.push(this.decryptChunk_(s.subarray(c,c+a),i,n,l))
for(c=a;c<s.length;c+=a){n=new Uint32Array([u(s[c-4]),u(s[c-3]),u(s[c-2]),u(s[c-1])])
this.asyncStream_.push(this.decryptChunk_(s.subarray(c,c+a),i,n,l))}this.asyncStream_.push((function(){r(null,(e=l).subarray(0,e.byteLength-e[e.byteLength-1]))

;/*! @name pkcs7 @version 1.0.4 @license Apache-2.0 */
var e}))}e.prototype.decryptChunk_=function(e,t,i,n){return function(){var r=function(e,t,i){var n,r,a,o,l,c,d,h,p,f=new Int32Array(e.buffer,e.byteOffset,e.byteLength>>2),m=new s(Array.prototype.slice.call(t)),g=new Uint8Array(e.byteLength),v=new Int32Array(g.buffer)
n=i[0]
r=i[1]
a=i[2]
o=i[3]
for(p=0;p<f.length;p+=4){l=u(f[p])
c=u(f[p+1])
d=u(f[p+2])
h=u(f[p+3])
m.decrypt(l,c,d,h,v,p)
v[p]=u(v[p]^n)
v[p+1]=u(v[p+1]^r)
v[p+2]=u(v[p+2]^a)
v[p+3]=u(v[p+3]^o)
n=l
r=c
a=d
o=h}return g}(e,t,i)
n.set(r,e.byteOffset)}}
t(e,null,[{key:"STEP",get:function(){return 32e3}}])
return e}()
self.onmessage=function(e){var t=e.data,i=new Uint8Array(t.encrypted.bytes,t.encrypted.byteOffset,t.encrypted.byteLength),n=new Uint32Array(t.key.bytes,t.key.byteOffset,t.key.byteLength/4),r=new Uint32Array(t.iv.bytes,t.iv.byteOffset,t.iv.byteLength/4)
new l(i,n,r,(function(e,i){self.postMessage(function(e){var t={}
Object.keys(e).forEach((function(i){var n=e[i]
ArrayBuffer.isView(n)?t[i]={bytes:n.buffer,byteOffset:n.byteOffset,byteLength:n.byteLength}:t[i]=n}))
return t}({source:t.source,decrypted:i}),[i.buffer])}))}